<?php
namespace undefined\DTO;
class FBColumnOptions{
	 /** @var FBFieldBaseOptions */
	 public $Field;
}



<?php
namespace undefined\DTO;
class FBFieldBaseOptions{
	 public $Id;
	 public $Type;
	 public $Label;
	 public $FieldName;
}



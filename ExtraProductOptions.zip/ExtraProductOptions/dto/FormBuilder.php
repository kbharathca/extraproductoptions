<?php
namespace undefined\DTO;
class FormBuilderOptions{
	 /** @var FBRowOptions[] */
	 public $Rows;
	 /** @var FieldTypeEnum[] */
	 public $DynamicFieldTypes;
}



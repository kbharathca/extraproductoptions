<?php
namespace undefined\DTO;
class FBRowOptions{
	 /** @var FBColumnOptions[] */
	 public $Columns;
}



<?php


namespace rednaowooextraproduct\pr\Utilities;


use rednaowooextraproduct\core\Loader;

class Activator
{

    /** @var License */
    public static $License=null;



    /**
     * @param $loader Loader
     * @param $licenseKey
     * @param $expirationDate
     * @param $url
     */
    public static function SaveLicense($loader,$licenseKey,$expirationDate,$url)
    {
        $license=new License();
        $license->ExpirationDate=$expirationDate;
        $license->LicenseKey=$licenseKey;
        $license->URL=$url;
        self::$License=$license;
        update_option($loader->Prefix.'_license',json_encode($license));
    }


    /**
     * @param $loader Loader
     * @return License
     */
    public static function GetLicense($loader){
        if(self::$License==null)
        {
            self::$License = \json_decode(\get_option($loader->Prefix.'_license', ''));
            if (self::$License== false)
                self::$License=new License();
        }
        return self::$License;
    }

    public static function SetRenewNotice($loader,$renewNotice)
    {
        \update_option($loader->Prefix.'_renew_notice',$renewNotice);
    }

    public static function ShouldShowRenewNotice($loader)
    {
        return \get_option($loader->Prefix.'_renew_notice',false)==true;
    }

    public static function GetLicenseKey($loader)
    {
        $license=self::GetLicense($loader);
        if($license==null)
            return '';
        return $license->LicenseKey;
    }

    /**
     * @param $loader Loader
     */
    public static function DeleteLicense($loader)
    {
        \delete_option($loader->Prefix.'_license');
        self::$License=null;
    }

    public static function LicenseIsActive($loader)
    {
        $license=Activator::GetLicense($loader);
        if($license->LicenseKey=='')
            return false;

        return $license->ExpirationDate>time();

    }

    public static function HasLicense($loader){
        return Activator::GetLicense($loader)->LicenseKey!='';
    }

}



class License{
    public $LicenseKey;
    public $ExpirationDate;
    public $URL;

    /**
     * License constructor.
     * @param License $data
     */
    public function __construct($data=null)
    {
        if($data==null)
        {
            $this->LicenseKey='';
            $this->ExpirationDate='';
            $this->URL;
        }else{
            $this->LicenseKey=$data->LicenseKey;
            $this->ExpirationDate=$data->ExpirationDate;
            $this->URL=$data->URL;
        }
    }


}
<?php

namespace rednaowooextraproduct\pr\Repositories;

use rednaowooextraproduct\core\Loader;
use rednaowooextraproduct\Utilities\ObjectSanitizer;

class GlobalProductRepository
{
    /** @var Loader */
    public $Loader;
    public function __construct($loader)
    {
        $this->Loader=$loader;
    }

    public function GetGlobalProductList(){
        global $wpdb;
        return $wpdb->get_results('select id Id,name Name,last_update LastUpdate,disabled Disabled from '.$this->Loader->GlobalTable);
    }

    public function SaveGlobalProduct($options,$serverOptions){
        global $wpdb;
        if($options==null)
            return false;

        $options=ObjectSanitizer::Sanitize($options,[
           "Id"=>0,
           "Name"=>"",
            "DynamicFieldTypes"=>[],
            "Rows"=>[],
            "Include"=>(object)["ConditionGroups"=>[]],
            "Exclude"=>(object)["ConditionGroups"=>[]],
            "ConflictStyle"=>"",
            "AdditionalDependencies"=>[]
        ]);



        if($options->Include!=null)
            if(count($options->Include->ConditionGroups)==0)
                $options->Include=null;
            else
                $options->Include=json_encode($options->Include);

        if($options->Exclude!=null)
            if(count($options->Exclude->ConditionGroups)==0)
                $options->Exclude=null;
            else
                $options->Exclude=json_encode($options->Exclude);



        $formOptions=(object)array(
            "DynamicFieldTypes"=>$options->DynamicFieldTypes,
            "Rows"=>$options->Rows,
            "AdditionalDependencies"=>$options->AdditionalDependencies
        );

        $this->MaybeAddProperty($formOptions,$options,'Styles');
        $this->MaybeAddProperty($formOptions,$options,'OptionsAmountLabel');
        $this->MaybeAddProperty($formOptions,$options,'FinalTotalLabel');
        $this->MaybeAddProperty($formOptions,$options,'OptionsAmountVisibility');
        $this->MaybeAddProperty($formOptions,$options,'TotalAmountVisibility');
        $this->MaybeAddProperty($formOptions,$options,'MultipleSteps');
        $this->MaybeAddProperty($formOptions,$options,'Fonts');
        if($options->Id==0)
        {
            $result=$wpdb->get_row($wpdb->prepare('select 1 from '.$this->Loader->GlobalTable.' where name=%s',$options->Name));
            if($result!=null)
            {
                throw new \Exception('The name already exists');
            }


            $result=$wpdb->insert($this->Loader->GlobalTable,array(
                'options'=>json_encode($formOptions),
                'conflict_style'=>$options->ConflictStyle,
                'include'=>$options->Include,
                'exclude'=>$options->Exclude,
                'name'=>$options->Name,
                'last_update'=>current_time('c'),
                'server_options'=>json_encode($serverOptions)
            ));

            if(!$result)
                throw new \Exception($wpdb->last_error);


            return $wpdb->insert_id;
        }else{
            $result=$wpdb->get_row($wpdb->prepare('select 1 from '.$this->Loader->GlobalTable.' where name=%s and id<>%d',$options->Name,$options->Id));
            if($result!=null)
            {
                throw new \Exception('The name already exists');
            }

            $result=$wpdb->update($this->Loader->GlobalTable,array(
                'options'=>json_encode($formOptions),
                'conflict_style'=>$options->ConflictStyle,
                'include'=>$options->Include,
                'exclude'=>$options->Exclude,
                'name'=>$options->Name,
                'last_update'=>current_time('c'),
                'server_options'=>json_encode($serverOptions)
            ),array('id'=>$options->Id));

             if($result===false)
                throw new \Exception($wpdb->last_error);


            return $options->Id;
        }

    }

    public function DeleteGlobalProducts($id)
    {
        global $wpdb;
        $result=$wpdb->delete($this->Loader->GlobalTable,array(
            'id'=>$id
        ));

        if($result===false)
            throw new \Exception($wpdb->last_error);
    }

    public function GetGlobalOptionsById($globalProductId)
    {
        global $wpdb;
        $row=$wpdb->get_row($wpdb->prepare('select conflict_style ConflictStyle,options Options,include Include,exclude Exclude,name Name,id Id,server_options ServerOptions from '.$this->Loader->GlobalTable.' where id=%d',$globalProductId));
        if($row==null)
            return null;

        $serverOptions=json_decode($row->ServerOptions);
        if($serverOptions==null)
            $serverOptions=[];

        $options=json_decode($row->Options);

        foreach($options->Rows as $currentRow)
        {
            foreach($currentRow->Columns as $currentColumn)
            {
                $currentColumn->Field->GlobalId=$globalProductId;
            }
        }
        $include=null;
        $exclude=null;
        $name='';
        $id=0;
        if($row->Include!=null)
            $include=json_decode($row->Include);

        if($row->Exclude!=null)
            $exclude=json_decode($row->Exclude);

        $object= (object)[
            "Id"=>$row->Id,
            "Name"=>$row->Name,
            "Rows"=>$options->Rows,
            "Styles"=>isset($options->Styles)?$options->Styles:'',
            "Fonts"=>isset($options->Fonts)?$options->Fonts:'',
            "DynamicFieldTypes"=>$options->DynamicFieldTypes,
            "Include"=>$include,
            "Exclude"=>$exclude,
            "ConflictStyle"=>$row->ConflictStyle,
            "AdditionalDependencies"=>$options->AdditionalDependencies
        ];


        $rowOptions=json_decode($row->Options);

        $this->MaybeAddProperty($object,$rowOptions,'Styles');
        $this->MaybeAddProperty($object,$rowOptions,'OptionsAmountLabel');
        $this->MaybeAddProperty($object,$rowOptions,'FinalTotalLabel');
        $this->MaybeAddProperty($object,$rowOptions,'OptionsAmountVisibility');
        $this->MaybeAddProperty($object,$rowOptions,'TotalAmountVisibility');
        $this->MaybeAddProperty($object,$rowOptions,'MultipleSteps');
        $this->MaybeAddProperty($object,$rowOptions,'Fonts');
        return ["Options"=>$object,"ServerOptions"=>$serverOptions];

    }

    public function GetConditions()
    {
        global $wpdb;
        $rows= $wpdb->get_results("select id Id,include Include, exclude Exclude,conflict_style ConflictStyle from ".$this->Loader->GlobalTable.' where include is not null and disabled <> 1 or disabled is null');

        foreach($rows as $currentRow)
        {
            if($currentRow->Include!=null)
                $currentRow->Include=json_decode($currentRow->Include);


            if($currentRow->Exclude!=null)
                $currentRow->Exclude=json_decode($currentRow->Exclude);
        }

        return $rows;
    }

    private function MaybeAddProperty($newOptions, $originalOptions,$property)
    {
        if(isset($originalOptions->$property))
            $newOptions->$property=$originalOptions->$property;

    }

    public function Clone($id)
    {
        global $wpdb;
        $row=$wpdb->get_results($wpdb->prepare('select options, conflict_style,include,exclude,name from '.$this->Loader->GlobalTable .' where id=%d',$id));
        if(count($row)==0)
            throw new \Exception('Global option was not found');

        if(!$wpdb->insert($this->Loader->GlobalTable,[
           'options'=>$row[0]->options,
            'conflict_style'=>$row[0]->conflict_style,
            'include'=>$row[0]->include,
            'exclude'=>$row[0]->exclude,
            'name'=>$row[0]->name.' Clone',
            'disabled'=>1,
            'last_update'=>date('c')
        ]))
            throw new \Exception('Could not clone record, pleaes try again');

        return $wpdb->insert_id;
    }

    public function ChangeStatus($id,$status)
    {
        global $wpdb;
        return $wpdb->update($this->Loader->GlobalTable,[
            'disabled'=>$status
        ],['id'=>$id]);
    }


}
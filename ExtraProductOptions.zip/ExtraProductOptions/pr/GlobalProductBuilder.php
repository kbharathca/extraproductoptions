<?php

namespace rednaowooextraproduct\pr;

use rednaowooextraproduct\core\Loader;
use rednaowooextraproduct\Integration\PluginsIntegration\PluginIntegrationManager;
use rednaowooextraproduct\pr\Repositories\GlobalProductRepository;
use rednaowooextraproduct\pr\Utilities\Activator;
use rednaowooextraproduct\repository\ProductRepository;

class GlobalProductBuilder
{
    /** @var Loader */
    public $Loader;
    public function __construct($loader)
    {
        $this->Loader=$loader;
    }

    public function Render(){
        if(!isset($_GET['GlobalProductId']))
            $this->RenderGlobalOptionsList();
        else
            $this->RenderGlobalOptionsBuilder();
    }

    private function RenderGlobalOptionsBuilder()
    {
        PluginIntegrationManager::Initialize($this->Loader);
        $post_id=get_the_ID();
        $currency=get_woocommerce_price_format();
        $repository=new GlobalProductRepository($this->Loader);

        $options=null;
        if($_GET['GlobalProductId']>0)
        {
            $globalOptions=$repository->GetGlobalOptionsById(intval($_GET['GlobalProductId']));
            $options=null;
            $serverOptions=[];
            if($globalOptions!=null)
            {
                $options = $globalOptions['Options'];
                $serverOptions = $globalOptions['ServerOptions'];
            }
        }


        $this->Loader->AddRNTranslator(array('ProductFieldBuilder','InternalShared','ProductDesignerPro','RunnableGlobalProductBuilder'));
        $this->Loader->AddScript('shared-core','js/dist/SharedCore_bundle.js',array('@RNTranslator','wp-element'));
        $this->Loader->AddScript('internal-shared','js/dist/InternalShared_bundle.js',array('@shared-core'));
        $this->Loader->AddScript('form-builder','js/dist/FormBuilder_bundle.js',array('wp-i18n','@RNTranslator','@internal-shared'));
        $this->Loader->AddStyle('form-builder','js/dist/FormBuilder_bundle.css');

        $this->Loader->AddScript('productquantity_calculator','js/dist/ProductQuantityCalculator_bundle.js',array('@form-builder'));
        $this->Loader->AddScript('formulaperitem_calculator','js/dist/FormulaPerItemCalculator_bundle.js',array('@form-builder'));

        $additionalFields=array();
        $additionalFields=\apply_filters('woo-extra-product-get-additional-fields',$additionalFields);
        $dependencies=array();
        foreach ($additionalFields as $field)
        {
            $dependencies[]='@'.$field;
            $this->Loader->AddScript($field,'js/dist/'.$field.'_bundle.js',array('@form-builder'));
        }
        $dependencies=apply_filters('woo-extra-product-fields-loaded',$dependencies);

        $fieldsWidthStyle=['FBAppointment','FBGroupButton','FBDatePicker','FBSizeChart','FBCollapsible','FBDateRange','FBDropDown','FBFile','FBGroupPanel','FBImagePicker','FBList','FBRepeater','FBSlider','FBRange','FBButtonSelection','FBSignature','FBColorSwatcher','FBTermOfService','FBSearchableSelect','FBLikertScale','FBSurvey'];
        foreach($fieldsWidthStyle as $currentDynamicField )
        {
            $this->Loader->AddStyle($currentDynamicField, 'js/dist/' . $currentDynamicField . '_bundle.css');
        }


        $dependencies=\apply_filters('woo-extra-product-load-designer',$dependencies);

        if($this->Loader->IsPR())
        {
            $this->Loader->AddScript('FormBuilderPr', 'js/dist/FormBuilderPr_bundle.js',array('@form-builder'));
        }


        $this->Loader->AddScript('products-builder','js/dist/ProductFieldBuilder_bundle.js', array('@form-builder'));
        $this->Loader->AddStyle('products-builder','js/dist/ProductFieldBuilder_bundle.css');

        $this->Loader->AddScript('GlobalProductBuilder','js/dist/GlobalProductOptions_bundle.js',array('@products-builder'));
        $this->Loader->AddStyle('GlobalProductBuilder','js/dist/GlobalProductOptions_bundle.css');


        if($this->Loader->IsPR())
        {
            $this->Loader->AddScript('multiplesteps','js/dist/MultipleSteps_bundle.js', array('@form-builder'));
            $this->Loader->AddScript('multiplestepsdesigner','js/dist/MultipleStepsDesigner_bundle.js', array('@products-builder'));
            $this->Loader->AddScript('OptionsPriceCondition','js/dist/ChangeOptionsPriceConditionProcessor_bundle.js', array('@products-builder'));
            $this->Loader->AddScript('ChangeImageCondition','js/dist/ChangeImageConditionProcessor_bundle.js', array('@products-builder'));


            $this->Loader->AddScript('MaximumNumberOfItems','js/dist/MaximumNumberOfItemsConditionProcessor_bundle.js', array('@products-builder'));

            $dependencies[]='@multiplesteps';
            $dependencies[]='@multiplestepsdesigner';
            $dependencies[]='@OptionsPriceCondition';
        }



        wp_enqueue_media();

        $this->Loader->AddScript('global-products-builder-runnable','js/dist/RunnableGlobalProductBuilder_bundle.js',\array_merge($dependencies, \array_merge($dependencies, array('@GlobalProductBuilder','@productquantity_calculator'))));
        $this->Loader->AddStyle('global-products-builder-runnable','js/dist/RunnableGlobalProductBuilder_bundle.css');

        $licenseKey='';
        $licenseIsActive=false;
        if($this->Loader->IsPR())
        {
            $licenseKey=Activator::GetLicenseKey($this->Loader);
        }

        $orderby = 'name';
        $order = 'asc';
        $hide_empty = false ;
        $cat_args = array(
            'orderby'    => $orderby,
            'order'      => $order,
            'hide_empty' => $hide_empty,
        );
        $product_categories = get_terms( 'product_cat', $cat_args );
        $categories=array();
        foreach($product_categories as $currentCategory)
        {
            $categories[]=array(
                'Id'=>$currentCategory->term_id,
                'Name'=>$currentCategory->name

            );
        }

        $productTags=array();
        $terms = get_terms('product_tag');
        foreach ($terms as $term) {
            $productTags[]= array(
                'Id'=>$term->term_id,
                'Name'=>$term->name
            );

        }


        if($options!=null)
            do_action('woo-extra-product-load-fonts',$options);

        $this->Loader->LocalizeScript('rednaoProductDesigner','products-builder','global_product',apply_filters('woo-extra-product-initialize-product-designer-var',array(
             'Fees'=>[],
            'ProductId'=>$post_id,
            'ServerOptions'=>$serverOptions,
            "Options"=>$options,
            'AllAttributes'=>[],
            'ProductNonce'=>\wp_create_nonce($post_id.'_product_designer'),
            'URL'=>$this->Loader->URL,
            'IsDesign'=>true,
            'IsGlobalDesign'=>true,
            'IsPr'=>$this->Loader->IsPR(),
            'PurchaseURL'=>'http://google.com',
            'GlobalProductURL'=>\admin_url('admin.php').'?page=woocommerce_extra_product_add_global_options',
            'WCCurrency'=>array(
                'Format'=>get_woocommerce_price_format(),
                'Decimals'=>wc_get_price_decimals(),
                'ThousandSeparator'=>wc_get_price_thousand_separator(),
                'DecimalSeparator'=>wc_get_price_decimal_separator(),
                'Symbol'=>get_woocommerce_currency_symbol()
            ),
            'Categories'=>$categories,
            'Tags'=>$productTags,
            "LicenseKey"=>$licenseKey,
            'SiteURL'=>\get_home_url(),
            "ItemId"=>$this->Loader->GetConfig('ItemId')
        )));


        ?>
        <div class="panel woocommerce_options_panel" id="rednao-advanced-products" style="padding: 10px">
            <input type="hidden" name="rednao_advanced_product_options" id="rednao_advanced_product_options_input" value=""/>
            <input type="hidden" name="rednao_advanced_product_server_options" id="rednao_advanced_product_server_options_input" value=""/>
            <div id="rednao-advanced-products-designer">
                Loading builder, please wait a bit...
            </div>
        </div>
        <?php
    }

    private function RenderGlobalOptionsList()
    {
        //$this->Loader->AddRNTranslator(array('GlobalProductList'));

        $this->Loader->AddScript('shared-core','js/dist/SharedCore_bundle.js',array('wp-element'));

        $this->Loader->AddRNTranslator(array('GlobalProductList'));
        $this->Loader->AddScript('products-builder','js/dist/GlobalProductList_bundle.js', array('@shared-core'));
        $this->Loader->AddStyle('products-builder','js/dist/GlobalProductList_bundle.css');


        $repository=new GlobalProductRepository($this->Loader);
        $this->Loader->LocalizeScript('rngloballistvar','products-builder','global_product',array(
            'PageURL'=>\admin_url('admin.php').'?page=woocommerce_extra_product_add_global_options',
            'GlobalProducts'=>$repository->GetGlobalProductList()
        ));
        echo "<div id='App'></div>";

    }

}
<?php
namespace rednaowooextraproduct\pr\Parser\Elements\Scalars;


use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseMethod extends ParserElementBase{

    public $Name;
    /** @var ParserElementBase[] */
    public $Args;
    public $Object;
    public $InstanceToUse;

    function __construct($Parent, $Data) {
        parent::__construct($Parent, $Data);
        $this->Args=[];
        $this->Name=$Data->Name;
        $this->Object=(ParseFactory::GetParseElement($this,$Data->Object))->Parse();
        if($Data->Args!=null)
        {
            foreach($Data->Args as $current)
                $this->Args[]=ParseFactory::GetParseElement($this,$current);
        }

        if($this->Object==null)
            throw new \Exception('Invalid method call '.$this->Name);

        $this->GetNameToUse();

    }

    public function GetNameToUse(){
        $methodToUse=$this->Name;

        if(!method_exists($this->Object,$methodToUse))
            $methodToUse='Get'.$methodToUse;

        if(!method_exists($this->Object,$methodToUse))
            throw new \Exception('Invalid method '.$this->Name);



        return $methodToUse;
    }

    public function Parse() {
        if($this->Object==null)
            throw new \Exception('Invalid method call '.$this->Name);

        $parsedArgs=array();

        foreach($this->Args as $current)
            $parsedArgs[]=$current->Parse();

        return \call_user_func_array(array($this->Object,$this->GetNameToUse()),$parsedArgs);

    }


}
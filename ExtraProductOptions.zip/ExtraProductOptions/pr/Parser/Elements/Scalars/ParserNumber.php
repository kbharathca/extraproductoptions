<?php
namespace rednaowooextraproduct\pr\Parser\Elements\Scalars;

use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;


class ParserNumber extends ParserElementBase{

    function __construct($Parent,$Data) {
        parent::__construct($Parent,$Data);

    }

    public function Parse(){
        return \floatval($this->Data->d);
    }
}
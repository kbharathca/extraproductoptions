<?php
namespace rednaowooextraproduct\pr\Parser\Elements\Scalars;


use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseField extends ParserElementBase{

    public $FieldId;
    /** @var FBFieldBase */
    public $Field;



    function __construct($Parent, $Data) {
        parent::__construct($Parent, $Data);
        $this->FieldId=$this->Data->Id;

        $self=$this;
        $main=$this->GetMain();
        $this->Field=array_filter($main->FieldList,function($element) use($self){
            return $element->Options->Id==$self->FieldId;
        });


        if(count($this->Field)==0)
            $this->Field=null;
        else
            $this->Field=current($this->Field);

    }

    function Parse() {
        if($this->Field==null)
            return 0;

        return $this->Field;
    }


}
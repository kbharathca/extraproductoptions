<?php
namespace rednaowooextraproduct\pr\Parser\Elements\Scalars;


use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseFixed extends ParserElementBase{

    public $Config;

    function __construct($Parent, $Data) {
        parent::__construct($Parent, $Data);

        $d=ParseFactory::GetParseElement($this,$Data->d);
        $json=$d->Parse();

        $this->Config=\json_decode($json);

    }

    function Parse() {
        if($this->GetMain()->Owner==null)
            return null;
        return $this->GetMain()->Owner->GetFixedValue($this->Config);
    }


}
<?php


namespace rednaowooextraproduct\pr\Parser\Elements;


use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseDeclaration extends ParserElementBase
{
    public $VariableName;
    /** @var ParserElementBase */
    public $Assignment;
    public function __construct($parent, $data)
    {
        parent::__construct($parent, $data);
        $this->VariableName=$data->Name;
        $this->Assignment=ParseFactory::GetParseElement($this,$data->Assignment);
    }


    public function Parse()
    {
        $value=$this->Assignment->Parse();
        $this->GetMain()->SetVariable($this->VariableName,$value);
        return $value;
    }
}
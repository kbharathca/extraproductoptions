<?php

namespace rednaowooextraproduct\pr\Parser\Elements;

use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseSentence extends ParserElementBase{

    /** @var ParserElementBase */
    public $Sentence;
    /** @var ParserElementBase */
    public $Next;

    function __construct($Parent,$Data) {
        parent::__construct($Parent,$Data);

        $this->Sentence=ParseFactory::GetParseElement($this,$this->Data->Sentence);
        if(isset($this->Data->Next))
            $this->Next=ParseFactory::GetParseElement($this,$this->Data->Next);
    }

    function Parse() {
        return $this->Sentence->Parse();
    }
}
<?php
namespace rednaowooextraproduct\pr\Parser\Elements\Operations\Logical;

use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseNegation extends ParserElementBase{
    /** @var ParserElementBase */
    public $Child;

    function __construct($Parent, $Data) {
        parent::__construct($Parent,$Data);

        $this->Child=ParseFactory::GetParseElement($this,$Data->Child);
    }

    function Parse() {
        return !$this->Child->Parse();
    }

}
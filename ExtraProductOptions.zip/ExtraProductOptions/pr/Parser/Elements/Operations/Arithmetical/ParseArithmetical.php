<?php

namespace rednaowooextraproduct\pr\Parser\Elements\Operations\Arithmetical;



use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;
use rednaowooextraproduct\pr\Parser\Core\ParserElementThatUsesFieldsBase;

class ParseArithmetical extends ParserElementThatUsesFieldsBase{

    /** @var ParserElementBase */
    public $Left;

    /** @var ParserElementBase */
    public $Right;


    function __construct($Parent,$Data) {
        parent::__construct($Parent,$Data);
        $this->Left=ParseFactory::GetParseElement($this,$this->Data->Left);
        $this->Right=ParseFactory::GetParseElement($this,$this->Data->Right);
    }

    function Parse() {
        switch ($this->Data->type) {
            case 'MUL':
                return $this->GetScalarOrPrice($this->Left->Parse())*$this->GetScalarOrPrice($this->Right->Parse());
            case 'ADD':
                $left=$this->Left->Parse();
                $right=$this->Right->Parse();

                if($left instanceof FBFieldBase)
                {
                    if(\is_string($right))
                        $left=$left->GetText();
                    else
                        $left=$this->GetScalarOrPrice($left);
                }

                if($right instanceof FBFieldBase)
                {
                    if(\is_string($left))
                        $right=$right->GetText();
                    else
                        $right=$this->GetScalarOrPrice($right);
                }

                if(\is_string($left)||\is_string($right))
                    return $left.$right;

                return $left+$right;
            case 'SUB':
                return $this->GetScalarOrPrice($this->Left->Parse())-$this->GetScalarOrPrice($this->Right->Parse());
            case 'DIV':
                if($this->GetScalarOrPrice($this->Right->Parse())==0)
                    return 0;
                return $this->GetScalarOrPrice($this->Left->Parse())/$this->GetScalarOrPrice($this->Right->Parse());

        }
    }

    function GetScalarOrPrice($data)
    {
        if($data instanceof FBFieldBase)
            return $this->GetPriceFromField($data);


        $total=$data;
        if(is_array($data)) {
            $total=0;
            foreach ($data as $currentItem)
                $total += floatval($currentItem);
        }

        return $total;

    }

}
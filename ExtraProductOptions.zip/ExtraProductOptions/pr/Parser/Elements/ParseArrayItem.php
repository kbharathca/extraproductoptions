<?php
namespace rednaowooextraproduct\pr\Parser\Elements;


use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseArrayItem extends ParserElementBase{

    /** @var ParserElementBase */
    public $Array;
    public $Index;
    function __construct($Parent,$Data) {
        parent::__construct($Parent,$Data);
        $this->Array=ParseFactory::GetParseElement($this,$Data->Array);
        $this->Index=intval($Data->Index);
        if(!is_numeric($Data->Index))
            throw new \Exception('Invalid array Index');

    }

    function Parse() {
        $array=$this->Array->Parse();
        if(!is_array($array))
            return null;

        if(!isset($array[$this->Index]))
        return null;

        return $array[$this->Index];
    }

}
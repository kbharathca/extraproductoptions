<?php


namespace rednaowooextraproduct\pr\Parser\Elements;



use Exception;
use rednaowooextraproduct\pr\Parser\Core\MethodDictionary;
use rednaowooextraproduct\pr\Parser\Core\ParseFactory;
use rednaowooextraproduct\pr\Parser\Core\ParserElementBase;

class ParseFunc extends ParserElementBase
{

    public $Method;
    /** @var ParserElementBase[] */
    public $Args;

    public function __construct($parent,$data)
    {
        parent::__construct($parent,$data);
        $this->Method=$this->Data->Method;
        $this->Args=[];
        foreach($data->Args as $current)
            $this->Args[]=ParseFactory::GetParseElement($this,$current);
    }


    public function Parse()
    {
        $methodDictionary=new MethodDictionary();

        $parsedArgs=array();

        foreach($this->Args as $current)
            $parsedArgs[]=$current->Parse();
        if(\method_exists($methodDictionary,$this->Method))
            return \call_user_func_array(array($methodDictionary,$this->Method),$parsedArgs);

        throw new Exception('Invalid function used '.$this->Method);
    }
}
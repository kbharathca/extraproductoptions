<?php

namespace rednaowooextraproduct\pr\Parser\Core;

use Exception;
use rednaowooextraproduct\pr\Parser\Elements\Math\ParseMathFunction;
use rednaowooextraproduct\pr\Parser\Elements\Operations\Arithmetical\ParseArithmetical;
use rednaowooextraproduct\pr\Parser\Elements\Operations\Logical\ParseComparator;
use rednaowooextraproduct\pr\Parser\Elements\Operations\Logical\ParseCondition;
use rednaowooextraproduct\pr\Parser\Elements\Operations\Logical\ParseConditionSentence;
use rednaowooextraproduct\pr\Parser\Elements\Operations\Logical\ParseNegation;
use rednaowooextraproduct\pr\Parser\Elements\ParseArray;
use rednaowooextraproduct\pr\Parser\Elements\ParseArrayItem;
use rednaowooextraproduct\pr\Parser\Elements\ParseBlock;
use rednaowooextraproduct\pr\Parser\Elements\ParseDeclaration;
use rednaowooextraproduct\pr\Parser\Elements\ParseFunc;
use rednaowooextraproduct\pr\Parser\Elements\ParseParenthesis;
use rednaowooextraproduct\pr\Parser\Elements\ParseReturn;
use rednaowooextraproduct\pr\Parser\Elements\ParseSentence;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParseField;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParseFixed;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParseMethod;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParserBoolean;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParserNumber;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParserString;
use rednaowooextraproduct\pr\Parser\Elements\Scalars\ParseVariable;

class ParseFactory {
    /**
     * @param $parent
     * @param $element
     * @return ParserElementBase
     */
    public static function GetParseElement($parent,$element)
    {
        if($element==null)
            return null;
        switch ($element->type) {
            case 'NUMBER':
                return new ParserNumber($parent,$element);
            case 'BOOLEAN':
                return new ParserBoolean($parent,$element);
            case 'STRING':
                return new ParserString($parent,$element);
            case 'MATH':
                return new ParseMathFunction($parent,$element);
            case 'MUL':
            case 'ADD':
            case 'SUB':
            case 'DIV':
                return new ParseArithmetical($parent,$element);
            case 'SENTENCE':
                return new ParseSentence($parent,$element);
            case 'P':
                return new ParseParenthesis($parent,$element);
            case 'CONDSENTENCE':
                return new ParseConditionSentence($parent,$element);
            case 'COMPARATOR':
                return new ParseComparator($parent,$element);
            case 'CONDITION':
                return new ParseCondition($parent,$element);
            case 'FIELD':
                return new ParseField($parent,$element);
            case 'ARR':
                return new ParseArray($parent,$element);
            case 'NEGATION':
                return new ParseNegation($parent,$element);
            case 'BLOCK':
                return new ParseBlock($parent,$element);
            case 'DECLARATION':
                return new ParseDeclaration($parent,$element);
            case 'RETURN':
                return new ParseReturn($parent,$element);
            case 'VARIABLE':
                return new ParseVariable($parent,$element);
            case 'FIXED':
                return new ParseFixed($parent,$element);
            case 'FUNC':
                return new ParseFunc($parent,$element);
                break;
            case 'METHOD':
                return new ParseMethod($parent,$element);
            case 'ARRITEM':
                return new ParseArrayItem($parent,$element);
            default:
                throw new Exception('Invalid token '.$element->type);



        }
    }
}
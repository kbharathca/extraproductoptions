<?php


namespace rednaowooextraproduct\pr\Parser\Core;


use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;

class MethodDictionary
{
    function GetNumber($value)
    {
        if($value==null)
            return 0;

        if($value instanceof FBFieldBase)
            return $value->GetPrice();

        return \floatval($value);


    }

    function GetText($value)
    {
        if($value==null)
            return '';

        if($value instanceof FBFieldBase)
            return $value->GetText();

        return \strval($value);


    }



    function Round($value,$numberOfDecimals)
    {
        $number= $this->GetNumber($value);
        $decimals= $this->GetNumber($numberOfDecimals);

        return round($number,$decimals);
    }

    function Ceil($value)
    {
        return \ceil($this->GetNumber($value));
    }


    function Floor($value)
    {
        return \floor($this->GetNumber($value));
    }
}
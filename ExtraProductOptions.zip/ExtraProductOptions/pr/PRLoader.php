<?php


namespace rednaowooextraproduct\pr;


use Exception;
use rednaowooextraproduct\ajax\GlobalProductAjax;
use rednaowooextraproduct\core\Loader;

use rednaowooextraproduct\core\Managers\ConditionManager\ConditionManager;
use rednaowooextraproduct\core\Managers\FileManager\FileManager;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBMultipleOptionsField;
use rednaowooextraproduct\core\Managers\FormManager\FormBuilder;
use rednaowooextraproduct\pr\ajax\PRAjax;
use rednaowooextraproduct\pr\GlobalComparator\GlobalProcessor;
use rednaowooextraproduct\pr\Managers\CarFormatManager\CartFormatManager;

use rednaowooextraproduct\pr\Managers\FontFamiliManager\FontFamilyManager;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\FormulaCalculator;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBDateRange;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBFileField;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBGroupPanel;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBHiddenField;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBListField;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBRepeater;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBSizeChartField;
use rednaowooextraproduct\pr\Managers\OrderManager\OrderManager;
use rednaowooextraproduct\pr\Utilities\EDDUpdater;
use rednaowooextraproduct\repository\ProductRepository;
use rednaowooextraproduct\Utilities\Sanitizer;


class PRLoader
{
    /** @var Loader */
    public $Loader;
    public function __construct($loader)
    {
        $this->Loader=$loader;
        new EDDUpdater($this->Loader);
        \add_filter('woo-extra-product-get-additional-fields',array($this,'GetAdditionalFields'));
        \add_filter('woo-extra-product-load-designer',array($this,'LoadDesigner'));
        \add_filter('woo-extra-product-get-field-by-type',array($this,'GetPRFields'),10,6);
        \add_filter('woo-extra-product-before-add-order-meta',array($this,'BeforeAddOrderMeta'));
        \add_filter('rednaowooextraproduct_get_formula_calculator',array($this,'GetFormulaCalculator'),10,2);
        add_action('woocommerce_cart_calculate_fees',array($this,'WCCalculateFee'));
        \add_action('woo-extra-product-load-fonts',array($this,'LoadFonts'));
        add_filter('woo-extra-product-initialize-product-designer-var',array($this,'AddProductDesignerVar'));
        \add_action( 'admin_menu', array( $this, 'AddMenu' ), 1000 );
        new GlobalProductAjax($this->Loader,'rednaowooextraproduct');
        new CartFormatManager();
        new OrderManager();
        new GlobalProcessor($this->Loader);
        new PRAjax($this->Loader,'rednaowooextraproduct','');
    }

    public function WCCalculateFee(){
        $productRepository=new ProductRepository();
        $feeList=[];
        foreach(WC()->cart->get_cart_contents() as $currentContent)
        {
            if(!isset($currentContent['product_id'])||!isset($currentContent['rn_entry']))
                continue;


            $fees=json_decode($productRepository->GetProductFees($currentContent['product_id']));

            if($fees===null)
                continue;


            $condition=new ConditionManager();
            foreach($fees as $currentFee)
            {
                $formBuilder=new FormBuilder($this->Loader,$currentContent['rn_options'],$currentContent['rn_entry'],wc_get_product($currentContent['product_id']));
                $formBuilder->Initialize();
                if($condition->ShouldProcess($formBuilder,$currentFee))
                {
                    $name=Sanitizer::SanitizeString($currentFee->Name);
                    $price=Sanitizer::SanitizeNumber($currentFee->FeePrice);
                    $feeType=Sanitizer::SanitizeString($currentFee->FeeType);


                    switch ($feeType)
                    {
                        case 'Percentage':
                            $price=$currentContent['line_total']*($price/100);
                        case 'Fixed_Quantity':
                            $price*=$currentContent['quantity'];
                    }

                     if(!$currentFee->AddOnlyOnce)
                    {
                        if(isset($feeList[$name]))
                            $price+=$feeList[$name]["Price"];
                    }

                    $taxable=false;

                     if(isset($currentFee->Taxable))
                         $taxable=Sanitizer::SanitizeBoolean($currentFee->Taxable);


                    $feeList[$name]=[
                        "Price"=>$price,
                        "Taxable"=>$taxable,
                        "TaxClass"=>''
                    ];
                }
            }


        }
        foreach($feeList as $name=>$value)
            WC()->cart->add_fee($name,$value["Price"],$value['Taxable'],$value['TaxClass']);
    }
    public function LoadFonts($options){
        if(!isset($options->Fonts))
            return;

        $fontManager=new FontFamilyManager();
        if(isset($options->Fonts)&&is_array($options->Fonts))
            foreach($options->Fonts as $currentFont)
            {
                $fontManager->EnqueueFont($currentFont);
            }

    }

    public function AddProductDesignerVar($var){
        $fontManager=new FontFamilyManager();
        $var['Fonts']=$fontManager->GetFontFamilyList();
        return $var;
    }

    public function AddMenu(){
        add_submenu_page('woocommerce',__('Global product options',"rednaowooextraproduct"),__('Global product options',"rednaowooextraproduct"),
            'manage_woocommerce','woocommerce_extra_product_add_global_options',
            array($this,'AddGlobalOptions'));
    }

    public function AddGlobalOptions(){
        (new GlobalProductBuilder($this->Loader))->Render();
    }

    public function GetFormulaCalculator($return,$field)
    {
        return new FormulaCalculator($field);
    }

    public function BeforeAddOrderMeta($item)
    {
        if($item==null)
            return;
        if($item->Type=='fileupload')
        {
            foreach($item->Value as $fileToUpload)
            {
                $fileManager=new FileManager($this->Loader);
                $fileToUpload->Path=$fileManager->MaybeMoveToPermanentPath($fileToUpload->Path);
            }
        }

        if($item->Type=='repeater')
        {
            foreach ($item->Value as &$repeaterItem)
            {
                foreach($repeaterItem as &$field)
                {
                    $this->BeforeAddOrderMeta($field);
                }
            }
        }

        if($item->Type=='grouppanel'||$item->Type=='collapsible'||$item->Type=='popup')
        {
            foreach ($item->Value as &$repeaterItem)
            {
                $this->BeforeAddOrderMeta($repeaterItem);
            }
        }

    }

    public function LoadDesigner($dependencies)
    {
        $this->Loader->AddScript('FormulaParser','js/dist/FormulaParser_bundle.js',array('@form-builder','@products-builder'));
        $this->Loader->AddScript('DesignerPRO','js/dist/ProductDesignerPro_bundle.js',array('@form-builder','@products-builder','@FormulaParser'));

        $this->Loader->AddStyle('DesignerPRO','js/dist/ProductDesignerPro_bundle.css');

        return $dependencies;
    }

    public function GetAdditionalFields($fields){
        $fields[]='FBCollapsible';
        $fields[]='FBHidden';
        $fields[]='FBPopup';
        $fields[]='FBList';
        $fields[]='FBGroupPanel';
        $fields[]='FBFile';
        $fields[]='FBRepeater';
        $fields[]='FBImagePicker';
        $fields[]='FBDateRange';
        $fields[]='FBSizeChart';
        $fields[]='FBSearchableSelect';
        $fields[]='FBLikertScale';
        $fields[]='FBSurvey';
        $fields[]='FBGroupButton';
        $fields[]='FBRange';
        $fields[]='FBRating';
        $fields[]='FBAppointment';
        return $fields;
    }

    public function GetPRFields($field,$loader,$fieldType,$column,$fieldOptions,$entry)
    {
        if($field!=null)
            return $field;
        switch ($fieldType)
        {
            case 'hidden':
                return new FBHiddenField($loader,$column,$fieldOptions,$entry);
            case 'list':
                return new FBListField($loader,$column,$fieldOptions,$entry);
            case 'fileupload':
                return new FBFileField($loader,$column,$fieldOptions,$entry);
            case 'grouppanel':
            case 'popup':
            case 'globalcontainer':
            case 'collapsible':
                return new FBGroupPanel($loader,$column,$fieldOptions,$entry);
            case 'repeater':
                return new FBRepeater($loader,$column,$fieldOptions,$entry);
            case 'imagepicker':
                return new FBMultipleOptionsField($loader,$column,$fieldOptions,$entry);
            case 'daterange':
                return new FBDateRange($loader,$column,$fieldOptions,$entry);
            case 'sizechart':
                return new FBSizeChartField($loader,$column,$fieldOptions,$entry);

        }
    }
}
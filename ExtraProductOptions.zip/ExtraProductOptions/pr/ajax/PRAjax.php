<?php

namespace rednaowooextraproduct\pr\ajax;

use rednaowooextraproduct\ajax\AjaxBase;
use rednaowooextraproduct\pr\Managers\AppointmentManager\AppointmentManager;

class PRAjax extends AjaxBase
{


    protected function RegisterHooks()
    {
        $this->RegisterPublic('qp_get_available_dates','GetAvailableDates',false);
        add_action('qp_get_available_dates',array($this,'GetAvailableDates'));
    }

    public function GetAvailableDates(){
        $startDate=$this->GetRequired('StartDate');
        $endDate=$this->GetRequired("EndDate");
        $nonce=$this->GetRequired('Nonce');
        $options=$this->GetRequired('Options',null);

        if($options==null)
        {

        }



        $appointmentManager=new AppointmentManager($options);

        $this->SendSuccessMessage($appointmentManager->GetAvailableSlots($startDate,$endDate));
    }
}
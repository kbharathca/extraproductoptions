<?php


namespace rednaowooextraproduct\pr\Managers\OrderManager;


class OrderManager
{
    public function __construct()
    {
        add_filter('woo-extra-products-prepare-order-item',array($this,'PrepareOrderItem'),10,2);
    }


    public function PrepareOrderItem($formated,$orderItem)
    {
        if(!isset($orderItem->Type))
            return;
        switch($orderItem->Type)
        {
            case 'list':

        }
        $a=1;
    }

}
<?php

namespace rednaowooextraproduct\pr\Managers\AppointmentManager;

use DateTime;
use rednaowooextraproduct\core\Utils\ArrayUtils;

class AppointmentManager
{
    public $Options;

    /** @var \DateTime */
    private $MinDate;
    /** @var \DateTime */
    private $MaxDate;
    private $Holidays=null;
    private $Intervals=null;
    public $PreviousAppointments=null;

    public function __construct($options)
    {
        $this->Options=$options;
    }

    public function GetAvailableSlots($startDate, $endDate)
    {
        $this->PreviousAppointments=null;
        $startDate=new \DateTime($startDate);
        $endDate=new \DateTime($endDate);


         if($startDate>=$endDate)
            return [];

        $slots=[];
        while($startDate<$endDate)
        {
            $daySlots=$this->GetSlotsForDay($startDate);
            if(count($daySlots)>0)
            {
                $slots[$startDate->format('Y/n/j')]=$daySlots;
            }
            $startDate=$startDate->add(new \DateInterval('P1D'));
        }

        return $slots;

    }

    private function GetSlotsForDay(\DateTime $startDate)
    {
        if(!$this->DateCanHaveSlots($startDate))
            return [];

        if($this->Options->AppointmentDuration<=0||!is_numeric($this->Options->AppointmentDuration))
            return [];


        $slots=[];
        $current_time = current_time( 'mysql' ); // Get the current time in the MySQL datetime format
        $now = date_create( $current_time );
        $isCheckingToday=$startDate->format('Y-m-d')==$now->format('Y-m-d');
        $minutesPassed=0;
        if($isCheckingToday)
            $minutesPassed=intval($now->format('H'))*60+intval($now->format('i'));
        foreach($this->Options->Intervals as $currentInterval)
        {
            if(!in_array($startDate->format('w'),$currentInterval->AvailableDays))
                continue;
            foreach ($currentInterval->TimeRanges as $timeRange)
            {
                if (!is_numeric($timeRange->From) || !is_numeric($timeRange->To) || $timeRange->From >= $timeRange->To)
                    continue;

                $nextTime = $timeRange->From;
                while ($nextTime < $timeRange->To)
                {
                    $currentTime = $nextTime;
                    $nextTime += $this->Options->AppointmentDuration;

                    if ($this->Options->MaximumAppointmentsPerSlot != '' && is_numeric($this->Options->MaximumAppointmentsPerSlot))
                    {
                        $date = date_create($startDate->format('Y-m-d') . date(" H:i:s", $currentTime * 60));

                    }

                    if (ArrayUtils::Some($slots, function ($slot) use ($currentTime) {
                        return $slot["From"] == $currentTime;
                    }))
                        continue;

                    if ($this->Options->MinDate !== '0' || !$isCheckingToday || $minutesPassed < $currentTime)
                        $slots[] = array(
                            "Date" => strtotime($startDate->format('Y-m-d') . date(" H:i:s", $currentTime * 60)),
                            "From" => $currentTime,
                            "To" => $currentTime + $this->Options->AppointmentDuration,
                            "Label" => $this->FormatTime($currentTime * 60)
                        );


                }

            }
        }

        return $slots;
    }

    private function DateCanHaveSlots(\DateTime $startDate)
    {
        $minDate=$this->GetMinDate();
        $maxDate=$this->GetMaxDate();

        if($minDate!=null && $startDate<$minDate)
            return false;

        if($maxDate!=null && $startDate>$maxDate)
            return false;


        $holidays=$this->GetHolidays();


        foreach($holidays as $currentHoliday)
        {
            if($currentHoliday->From<=$startDate && $currentHoliday->To>=$startDate)
                return false;
        }
        return true;
    }

    private function GetMinDate(){
        if($this->MinDate!=null)
            return $this->MinDate;

        if($this->Options->MinDate=='')
            return null;

        if(is_numeric($this->Options->MinDate))
            $this->MinDate=new \DateTime("today +".$this->Options->MinDate." days");
        else{
            if(preg_match('/[0-9][0-9][0-9][0-9]\/[0-9][0-9]\/[0-9][0-9]/',trim($this->Options->MinDate)))
                $this->MinDate=new \DateTime(trim($this->Options->MinDate));
        }

        return $this->MinDate;
    }

    private function GetMaxDate(){
        if($this->MaxDate!=null)
            return $this->MaxDate;

        if($this->Options->MaxDate=='')
            return null;

        if(is_numeric($this->Options->MaxDate))
            $this->MaxDate=new \DateTime("today +".$this->Options->MaxDate." days");
        else{
            if(preg_match('/[0-9][0-9][0-9][0-9]\/[0-9][0-9]\/[0-9][0-9]/',trim($this->Options->MaxDate)))
                $this->MaxDate=new \DateTime(trim($this->Options->MaxDate));
        }

        return $this->MaxDate;
    }

    private function GetHolidays()
    {
        if($this->Holidays!=null)
            return $this->Holidays;

        $this->Holidays=[];
        foreach($this->Options->Holidays as $holiday)
        {
            if(preg_match('/[0-9][0-9][0-9][0-9]\/[0-9][0-9]\/[0-9][0-9]/',trim($holiday->From))&&
                preg_match('/[0-9][0-9][0-9][0-9]\/[0-9][0-9]\/[0-9][0-9]/',trim($holiday->To)))
                $this->Holidays[]=(object)[
                    "From"=>new \DateTime($holiday->From),
                    "To"=>new \DateTime($holiday->To)
                ];
        }

        return $this->Holidays;

    }

    private function FormatTime($time)
    {
        if($this->Options->TimeFormat=="24")
            return date("H:i", $time);
        else
            return date("g:i A", $time);
    }

    /**
     * @param DateTime $date
     * @return []
     */



}
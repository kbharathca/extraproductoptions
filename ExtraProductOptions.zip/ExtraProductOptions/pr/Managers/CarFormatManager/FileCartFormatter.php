<?php


namespace rednaowooextraproduct\pr\Managers\CarFormatManager;


use rednaowooextraproduct\core\Loader;
use rednaowooextraproduct\core\Managers\FileManager\FileManager;
use rednaowooextraproduct\Utilities\Sanitizer;

class FileCartFormatter
{
    public $Value;
    public $Options;
    public function __construct($value,$fieldOptions=null)
    {
        $this->FieldOptions=$fieldOptions;
        $this->Value=$value;
    }


    public function Format($includeLabel)
    {
        $html="<div style='width: 100%'>";
        if($includeLabel)
            $html.="<label style='font-weight: bold;'>" . esc_html($this->Value->Label) . ":</label>";
        $html.="<table style='border-bottom: none;'>";
        $html.='<tbody>';

        $rowNumber=0;
        $params=null;
        /** @var Loader $loader */
        $loader=apply_filters('woo_extra_products_get_loader',$params);
        $valueUrls=[];
        foreach($this->Value->Value as $valueRow)
        {
            $fileManager=new FileManager($loader);
            $additionalParams='';
            if(strpos($valueRow->Path,$fileManager->GetTempFolderRootPath())===0)
            {
                $additionalParams='&temp=true';

            }
            $valueUrls[]=admin_url( 'admin-ajax.php').'?action='.$loader->Prefix.'_getpublicfileupload&path='.basename($valueRow->Path).'&name='.$valueRow->Name.$additionalParams;;
            $html.='<tr>';
            $html.='<td style="border:none;">';
            if(Sanitizer::GetValueFromPath($this->FieldOptions,['ShowImagesInCart'],true)&& (substr_compare($valueRow->Name, '.png', -strlen('.png')) === 0||substr_compare($valueRow->Name, '.jpeg', -strlen('.jpeg')) === 0||
                substr_compare($valueRow->Name, '.jpg', -strlen('.jpg')) === 0))
            {

                $fileManager=new FileManager($loader);
                $additionalParams='';
                if(strpos($valueRow->Path,$fileManager->GetTempFolderRootPath())===0)
                {
                    $additionalParams='&temp=true';

                }

                $url=admin_url( 'admin-ajax.php').'?action='.$loader->Prefix.'_getpublicfileupload&path='.basename($valueRow->Path).'&name='.$valueRow->Name.$additionalParams;
                $html.='<img style="max-width:100px;max-height:100px;" src="'.esc_attr($url).'"/>';


            }else
                $html.=\esc_html($valueRow->Name);
            $html.='</td>';
            $html.='</tr>';
        }

        $html.='</tbody></table>';
        $html.='</div>';
        return [array('name'=>$this->Value->Label,'value'=>implode(', ',$valueUrls),'field'=>$this->Value,'key'=>$this->Value->Label,'display'=>$html)];
    }

}
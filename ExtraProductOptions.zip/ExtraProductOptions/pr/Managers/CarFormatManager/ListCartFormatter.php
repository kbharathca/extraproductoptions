<?php


namespace rednaowooextraproduct\pr\Managers\CarFormatManager;


class ListCartFormatter
{
    public $Value;
    public function __construct($value)
    {
        $this->Value=$value;
    }

    public function Format($includeLabel=true)
    {
        $values=[];
        $html="<div style='width: 100%'>";
        if($includeLabel)
            $html.="<label style='font-weight: bold;'>" . esc_html($this->Value->Label) . ":</label>";
        $html.="<table style='border-bottom: none;'>";
        $html.='<tbody>';

        $rowNumber=0;
        foreach($this->Value->Value as $valueRow)
        {
            $rowNumber++;
            $numberLabel='';

            if(\count($this->Value->Value)>1)
                $numberLabel=' #'.$rowNumber;

            $rows=[];
            for($i=0;$i<count($valueRow);$i++)
            {
                $rows[]=$valueRow[$i];
                $html.='<tr>';
                $html.='<td style="border:none;">';
                if($this->HadHeaders())
                {
                    $html.='<strong>'. \esc_html($this->Value->Columns[$i]->Name).$numberLabel.':</strong> ';
                }
                $html.=\esc_html($valueRow[$i]);
                $html.='</td>';
                $html.='</tr>';
            }

            if(count($rows)>0)
                $values[]=implode('|',$rows);
        }

        $html.='</tbody></table>';
        $html.='</div>';
        return [array('name'=>$this->Value->Label,'value'=>implode(', ',$values),'field'=>$this->Value,'key'=>$this->Value->Label,'display'=>$html)];
    }

    private function HadHeaders()
    {
        if(count($this->Value->Columns)==0)
            return false;

        foreach($this->Value->Columns as $column)
            if(\strlen(trim($column->Name))!='')
                return true;

        return false;
    }

}
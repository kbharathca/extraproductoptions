<?php


namespace rednaowooextraproduct\pr\Managers\CarFormatManager;


use rednaowooextraproduct\core\Managers\CartItemPrinter\CartItemPrinter;
use rednaowooextraproduct\Utilities\Sanitizer;

class CartFormatManager
{
    public function __construct()
    {
        \add_filter('woo_extra_products_display_list_for_cart',array($this,'CartFormat'),10,3);

        \add_filter('woo_extra_products_display_range_for_cart',array($this,'RangeFormat'),10,4);
        \add_filter('woo_extra_products_display_survey_for_cart',array($this,'SurveyFormat'),10,4);
        \add_filter('woo_extra_products_display_fileupload_for_cart',array($this,'FileUploadCartFormat'),10,4);
        \add_filter('woo_extra_products_display_grouppanel_for_cart',array($this,'GroupPanelFormat'),10,4);
        \add_filter('woo_extra_products_display_globalcontainer_for_cart',array($this,'GroupPanelFormat'),10,4);
        \add_filter('woo_extra_products_display_collapsible_for_cart',array($this,'GroupPanelFormat'),10,4);
        \add_filter('woo_extra_products_display_popup_for_cart',array($this,'GroupPanelFormat'),10,4);
        \add_filter('woo_extra_products_display_repeater_for_cart',array($this,'RepeaterFormat'),10,4);
        \add_filter('woo_extra_products_display_imagepicker_for_cart',array($this,'ImagePickerFormat'),10,4);
        \add_filter('woo_extra_products_display_daterange_for_cart',array($this,'DateRangeFormat'),10,4);
        \add_filter('woo_extra_products_display_sizechart_for_cart',array($this,'SizeChartFormat'),10,4);
        \add_filter('woo_extra_products_display_rating_for_cart',array($this,'RatingFormat'),10,4);
    }

    public function RangeFormat($return,$value,$includeLabel=true,$field=null){

        $plainValue='';

        if(is_Array($value->Value))
        {
            foreach($value->Value as $currentValue)
            {
                if($plainValue!='')
                    $plainValue.='-';
                $plainValue.=$currentValue->Value;

            }
        }

        return [array('name'=>$value->Label,'value'=>$plainValue,'field'=>$field,'key'=>$value->Label,'display'=>$plainValue)];
    }

    public function RatingFormat($return,$value,$includeLabel=true,$field=null){

        $currentValue=Sanitizer::SanitizeNumber(Sanitizer::GetStringValueFromPath($value,['Value','Value'],0));

        return [array('name'=>$value->Label,'value'=>$currentValue,'field'=>$field,'key'=>$value->Label,'display'=>$currentValue)];
    }


    public function SurveyFormat($return,$value,$includeLabel=true,$field=null){
        if($value==null||!isset($value->SelectedValues)||!is_array($value->SelectedValues))
            return '';

        $items=[];
        foreach($value->SelectedValues as $currentValue)
        {

            $rowLabel=Sanitizer::GetStringValueFromPath($currentValue,['Row','Label']);
            $columnLabel=Sanitizer::GetStringValueFromPath($currentValue,['Column','Label']);
            $rowId=Sanitizer::GetStringValueFromPath($currentValue,['Row','Id']);

            if(!isset($items[$rowId]))
            {
                $items[$rowId]['Row'] =$rowLabel;
                $items[$rowId]['Columns']=[];
            }

            $items[$rowId]['Columns'][]=$columnLabel;
        }

        $itemsToReturn=[];

        foreach($items as $currentItem)
        {
            $itemsToReturn[]=array('name'=>$currentItem['Row'],'value'=>implode(', ',$currentItem['Columns']),'key'=>$currentItem['Row'],'display'=>implode(', ',$currentItem['Columns']));

        }

        return $itemsToReturn;
    }

    public function SizeChartFormat($return,$value,$includeLabel=true,$field=null){
        if(!isset($value->Value))
            return '';

        $html='';



        $html.="";
        $html.='<div style="clear: both;width:100%;">';
        $values=[];
        for($i=0;$i<count($value->SelectedValues);$i++)
        {
            $currentRow=$value->SelectedValues[$i];
            if($i>0)
            {
                $html.="<hr/>";
            }
            $rowValue=[];
            for($t=0;$t<count($currentRow->Columns);$t++)
            {
                $column=null;
                $header=null;
                if($t<count($currentRow->Columns))
                    $column=$currentRow->Columns[$t];
                if($t<count($value->Headers))
                    $header=$value->Headers[$t];

                if($column!=null){
                    $html.='<div class="sizeChartRow" style="margin-bottom: 3px;clear:both;">';
                    if($header!=null)
                    {
                        $html.='<span style="font-weight: bold">'.$header->Text.':</span>';
                    }
                    $text=str_replace('<p','<span',$column->Text);
                    $text=str_replace('</p','</span',$text);
                    $html.='<span class="sizeChartValue" style="margin-left: 3px">'.$text.'</span>';
                    $rowValue[]=wp_kses($column->Text,'');
                    $html.='</div>';

                }

            }
            $values[]=implode('|',$rowValue);

        }

        $html.='</div>';
        return [array('name'=>$value->Label,'value'=>implode(', ',$values),'field'=>$field,'key'=>$value->Label,'display'=>$html)];

    }


    public function CartFormat($return,$value,$includeLabel=true,$field=null){

        return (new ListCartFormatter($value))->Format($includeLabel);

    }

    public function FileUploadCartFormat($return,$value,$includeLabel=true,$field=null)
    {
        return (new FileCartFormatter($value,$field))->Format($includeLabel);
    }

    public function GroupPanelFormat($return,$value,$includeLabel,$field=null)
    {
        $cartPrinter=new CartItemPrinter($value->Value,$field);
        return $cartPrinter->GetItemData(false);

    }

    public function DateRangeFormat($return,$value,$includeLabel=true,$field=null)
    {
        $plainValue='';
        $html='';
        if(isset($value->Value)&&isset($value->Value->StartDateLabel))
        {
            $plainValue=$value->Value->StartValue;
            $html .= "
                    <div style='width: 100%'>
                        <label style='font-weight: bold;'>" . esc_html($value->Value->StartDateLabel) . ":</label>
                        <label> " . esc_html($value->Value->StartValue) . "</label>
                    </div>    
                ";
        }


        if(isset($value->Value)&&isset($value->Value->EndDateLabel))
        {
            if($plainValue!='')
                $plainValue.='-';
            $plainValue.=$value->Value->EndValue;
            $html .= "
                    <div style='width: 100%'>
                        <label style='font-weight: bold;'>" . esc_html($value->Value->EndDateLabel) . ":</label>
                        <label> " . esc_html($value->Value->EndValue) . "</label>
                    </div>    
                ";
        }

        return [array('name'=>$value->Label,'value'=>$plainValue,'field'=>$field,'key'=>$value->Label,'display'=>$html)];
    }

    public function RepeaterFormat($return,$value,$includeLabel=true,$field=null)
    {
        $html='<div>';
        $hasMoreThanOne=count($value->Value);
        if(trim($value->Label)!=''&&$includeLabel)
            $html.='<h4 style="margin:0;border-bottom: 1px dashed #dfdfdf;">'.\esc_html($value->Label).'</h4>';

        $items=[];

        $index=0;
        foreach ($value->Value as $item)
        {
            $cartPrinter=new CartItemPrinter($item,$field,$index);
            $index++;
            $itemData=$cartPrinter->GetItemData($includeLabel);
            if(count($itemData)>0)
                $items=array_merge($items,$itemData);
            foreach($itemData as $currentData)
            {
                $html.=$currentData['display'];
            }
            if($hasMoreThanOne)
                $html.='<hr style="margin:4px 0;"/>';
        }
        return $items;
    }

    public function ImagePickerFormat($return,$value,$includeLabel=true,$field=null){

        $html='';
        if(trim($value->Label)!=''&&$includeLabel)
            $html='<label style="font-weight: bold;width:100%;">'.\esc_html($value->Label).':</label>';

        $values=[];

        foreach($value->SelectedValues as $currentValue)
        {
            $values[]=$currentValue->Value;
            $html.='<div class="imagepicker-container" style="text-align: center;width: 100%;max-width: 150px;">
                        <img style="width: 100%" src="'.esc_attr($currentValue->URL).'"/>';
            if(trim($currentValue->Value)!='')
                $html.='<span style="display: block;">'.trim($currentValue->Value).'</span>';
            $html.='</div>';
        }

        return [array('name'=>$value->Label,'value'=>implode(', ',$values),'field'=>$field,'key'=>$value->Label,'display'=>$html)];
    }

}
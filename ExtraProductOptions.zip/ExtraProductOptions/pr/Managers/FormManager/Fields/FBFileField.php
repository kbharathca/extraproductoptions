<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;


use rednaowooextraproduct\core\Managers\FileManager\FileManager;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\core\Managers\SlateGenerator\Core\HtmlTagWrapper;


class FBFileField extends FBFieldBase
{
    public function GetValue()
    {
        return $this->GetEntryValue('Value','');
    }

    public function GetLineItems(){
        $fileManager=new FileManager($this->Loader);
        $tempPath=$fileManager->GetTempFolderRootPath();
        foreach($this->Entry->Value as $file)
        {

            if(isset($file->Path)&&trim($file->Path)!='')
            {
                if(dirname(realpath($file->Path))!=realpath($tempPath))
                {
                    $file->Path='';
                    $file->Name='';
                }

                break;
            }
           $name='rnProFile'.$this->Options->Id.'@'.$file->Id;
            if(!isset($_FILES[$name]))
            {
                $file->Pyshical='';
                continue;
            }

            $file->Path=$fileManager->TemporaryUploadFile($name);
        }


        if($this->Entry==null||$this->GetEntryValue('Value','')==='')
            return array();


        $value=$this->GetEntryValue('Value','');

        return array((object)\array_merge((array)$this->Entry,array(
            'HideInCart'=>false,
            'Id'=>$this->Options->Id,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        )));
    }

    public function GetHtml($document)
    {
        $container=new HtmlTagWrapper($document,$document->createElement('div'));

        $values=$this->GetEntryValue('Value',array());
        $prefix=$this->Loader->Prefix;

        foreach($values as $currentValue)
        {
            $name=$currentValue->Name;
            $path=basename($currentValue->Path);


            $url=admin_url( 'admin-ajax.php').'?action='.$prefix.'_getpublicfileupload&path='.$path.'&name='.$name;

            $fileContent=$container->CreateAndAppendChild('div');

            if(\file_exists($currentValue->Path))
            {
                $fileInfo = getimagesize($currentValue->Path);
                $image_type = $fileInfo[2];
                if (in_array($image_type, array(IMAGETYPE_GIF, IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_BMP)))
                {
                    $img=$fileContent->CreateAndAppendChild('img');
                    $img->SetAttribute('src',$url);
                    $img->SetAttribute('alt','url');
                    $img->AddStyles(array('max-width'=>'200px','max-height'=>'200px'));
                }

                continue;
            }

            $link=$fileContent->CreateAndAppendChild('a');
            $link->SetAttribute('href',$url);
            $link->SetText($name);


        }

        return $container;
    }



}
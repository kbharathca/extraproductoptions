<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;


use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorFactory;
use rednaowooextraproduct\core\Managers\FormManager\Calculator\PricePerItemCalculator;
use rednaowooextraproduct\core\Managers\FormManager\FBRow;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FieldFactory;
use rednaowooextraproduct\core\Managers\SlateGenerator\Core\HtmlTagWrapper;

use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupCalculator;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupOfFieldsInGroupCalculator;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupPricePerItemCalculator;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\PricePerDayCalculator;
use stdClass;

class FBDateRange extends FBFieldBase
{
    public function GetValue()
    {
        return $this->GetEntryValue('Value','');
    }

    public function GetLineItems(){
        if($this->Entry==null||$this->GetEntryValue('Value','')==='')
            return array();


        return array((object)\array_merge((array)$this->Entry,array(
            'Id'=>$this->Options->Id,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        )));
    }

    public function GetHtml($document)
    {
        $container=new HtmlTagWrapper($document,$document->createElement('table'));
        $body=$container->CreateAndAppendChild('tbody');
        $row=$body->CreateAndAppendChild('tr');
        $value=$this->GetEntryValue('Value','');

        if($value=='')
            return null;

        $startDateContainer=$row->CreateAndAppendChild('td');
        $startDateLabel=$startDateContainer->CreateAndAppendChild('div');
        $startDateLabel->SetText($value->StartDateLabel);
        $startDateLabel->AddStyle('font-weight','bold');
        $startDateValue=$startDateContainer->CreateAndAppendChild('div');
        $startDateValue->SetText($value->StartValue);


        $endDateContainer=$row->CreateAndAppendChild('td');
        $endDateLabel=$endDateContainer->CreateAndAppendChild('div');
        $endDateLabel->SetText($value->StartDateLabel);
        $endDateLabel->AddStyle('font-weight','bold');
        $endDateValue=$endDateContainer->CreateAndAppendChild('div');
        $endDateValue->SetText($value->StartValue);

        return $container;

    }

    public function GetDays(){
        if($this->Entry==null||$this->Entry->Value->EndUnix==0||$this->Entry->Value->StartUnix==0)
            return 0;

        return ($this->Entry->Value->EndUnix-$this->Entry->Value->StartUnix)/60/60/24;
    }

}
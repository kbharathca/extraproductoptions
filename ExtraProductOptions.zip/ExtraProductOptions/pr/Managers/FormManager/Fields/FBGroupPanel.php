<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;



use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerDataRetriever;
use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerManager;
use rednaowooextraproduct\core\Managers\FormManager\FBRow;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;

use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupCalculator;
use stdClass;

class FBGroupPanel extends FBFieldBase implements ContainerDataRetriever
{
    public $Rows;
    /** @var FBFieldBase []*/
    public $Fields;
    public $Entries;
    /** @var ContainerManager */
    public $ContainerManager;
    public function __construct($loader, $fbColumn, $options,$entry=null)
    {
        parent::__construct($loader,$fbColumn, $options,$entry);

        $this->ContainerManager=new ContainerManager($this);
        $this->Calculator=new GroupCalculator($this);

        $this->Entries=new stdClass();
        $this->Entries->Fields=$this->GetEntryValue('Value',array());
        foreach($options->Rows as $currentRow)
        {
            $this->Rows[]=new FBRow($this->Loader,$this,$currentRow);
        }

        if(isset($this->Rows))
        {
            foreach ($this->Rows as $Row)
                foreach ($Row->Columns as $Column)
                    $this->Fields[] = $Column->Field;
        }

    }

    public function GetProductRegularPrice(){
        return $this->Column->Row->Form->GetProductRegularPrice();
    }

    public function GetProductSalePrice(){
        return $this->Column->Row->Form->GetProductRegularPrice();
    }

    public function GetValue()
    {
        return $this->GetEntryValue('Value','');
    }

    public function GetLineItems(){
        $lineItems=array();
        foreach($this->Fields as $field)
        {
            if($field->Entry==null)
                continue;
            $lineItems=\array_merge($lineItems,$field->GetLineItems());
        }


        return array((object)\array_merge((array)$this->Entry,array(
            'HideInCart'=>false,
            'Id'=>$this->Options->Id,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        )));
    }

    public function GetPriceOfNotDependantFields()
    {
        $total=0;
        foreach($this->Fields as $field)
        {
            if(!$field->Calculator->GetDependsOnOtherFields())
                $total+=$field->Calculator->GetPrice();
        }

        return $total;
    }


    public function GetHtml($document)
    {
        return $this->ContainerManager->GetHtml($document);
    }


    /**
     * @inheritDoc
     */
    public function GetRows()
    {
        return $this->Rows;
    }

    public function GetContainerManager()
    {
        return $this->ContainerManager;
    }
}
<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;


use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;

class FBHiddenField extends FBFieldBase
{
    public function GetValue()
    {
        return $this->GetEntryValue('Value','');
    }

    public function GetLineItems(){
        if($this->Entry==null||$this->GetEntryValue('Value','')==='')
            return array();


        return array((object)array(
            'Label'=>$this->GetEntryValue('Label',''),
            'Value'=>$this->GetEntryValue('Value',''),
            'HideInCart'=>true,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        ));
    }

}
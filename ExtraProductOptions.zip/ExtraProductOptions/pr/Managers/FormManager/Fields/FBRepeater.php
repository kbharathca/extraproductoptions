<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;



use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerDataRetriever;
use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerManager;
use rednaowooextraproduct\core\Managers\FormManager\FBColumn;
use rednaowooextraproduct\core\Managers\FormManager\FBRow;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupOfFieldsInGroupCalculator;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupPricePerItemCalculator;
use stdClass;

class FBRepeater extends FBFieldBase implements ContainerDataRetriever
{
    public $TemplateRows;
    /** @var FBFieldBase []*/
    public $Fields;
    public $Entries;
    /** @var FBRow[] */
    public $Rows;
    /** @var ContainerManager */
    public $ContainerManager;
    public function __construct($loader, $fbColumn, $options,$entry=null)
    {
        parent::__construct($loader, $fbColumn, $options,$entry);
        $this->ContainerManager=new ContainerManager($this);
        if($options->PriceType=='price_per_item')
            $this->Calculator=new GroupPricePerItemCalculator($this);
        if($options->PriceType=='sum_of_fields_in_group')
            $this->Calculator=new GroupOfFieldsInGroupCalculator($this);

        $this->Entries=new stdClass();
        $this->Entries->Fields=$this->GetEntryValue('Value',array());

        foreach($options->RowTemplates as $currentRow)
        {
            $this->TemplateRows[]=new FBRow($this->Loader,$this,$currentRow);
        }

        if(isset($this->TemplateRows))
            foreach($this->TemplateRows as $Row)
                foreach ($Row->Columns as $Column)
                    $this->Fields[]=$Column->Field;


        $repeaterItemOptions=new stdClass();
        $repeaterItemOptions->RowTemplates=$options->RowTemplates;
        $repeaterItemOptions->Type='repeater_item';

        foreach ($this->Entries->Fields as $repeaterItem)
        {

            $row=new FBRow($this->Loader,$this,null,null);
            $column=new FBColumn($this->Loader,$row,null,null);
            $row->AddColumn($column);
            $column->AddField(new FBRepeaterItem($this->Loader,$column,$repeaterItemOptions,$repeaterItem));

            $this->Rows[]=$row;
           /* $this->CreatedItems[]=&$newRepeaterItem;

            foreach($repeaterItem as $itemField)
            {
                foreach($this->Fields as $fieldOptions)
                {
                    if($fieldOptions->Options->Id==$itemField->Id)
                    {

                        $newRepeaterItem[]= FieldFactory::GetField($loader,null,\unserialize(\serialize($fieldOptions->Options)),$itemField);
                    }
                }
            }*/
        }



    }

    public function GetFieldTotal($fieldId)
    {
        $total=0;
        foreach($this->GetRepeaterItems() as $currentItem)
        {
            $field=$currentItem->ContainerManager->GetFieldById($fieldId);
            if($field!=null)
                $total+=$field->GetPrice();
        }

        return $total;
    }

    public function GetProductRegularPrice(){
        return $this->Column->Row->Form->GetProductRegularPrice();
    }

    public function GetProductSalePrice(){
        return $this->Column->Row->Form->GetProductRegularPrice();
    }

    public function GetValue()
    {
        return $this->GetEntryValue('Value',array());
    }

    /**
     * @return FBRepeaterItem[]
     */
    public function GetRepeaterItems()
    {
        $fields=[];
        foreach ($this->Rows as $row)
            foreach($row->Columns as $column)
            {
                $fields[]=$column->Field;
            }
        return $fields;
    }

    public function GetLineItems(){
        $lineItems=array();
        foreach($this->GetRepeaterItems() as $repeaterItem)
        {
            if(isset($newItems))
                unset($newItems);
            $newItems=array();
            $lineItems[]=&$newItems;

            foreach($repeaterItem->GetAllFields() as $field)
                $newItems=\array_merge($newItems,$field->GetLineItems());
        }


        return array((object)\array_merge((array)$this->Entry,array(
            'HideInCart'=>false,
            'Id'=>$this->Options->Id,
            'Value'=>$lineItems,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        )));
    }

    public function GetPriceOfNotDependantFields()
    {
        $total=0;
        foreach($this->Fields as $field)
        {
            if(!$field->Calculator->GetDependsOnOtherFields())
                $total+=$field->Calculator->GetPrice();
        }

        return $total;
    }

    public function GetHtml($document)
    {
        return $this->ContainerManager->GetHtml($document);
    }



    /**
     * @inheritDoc
     */
    public function GetRows()
    {
        return $this->Rows;
    }

    public function GetContainerManager()
    {
        return $this->ContainerManager;
    }
}
<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;


use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\core\Managers\SlateGenerator\Core\HtmlTagWrapper;

class FBListField extends FBFieldBase
{
    public function GetValue()
    {
        return $this->GetEntryValue('Value','');
    }

    public function GetLineItems(){
        if($this->Entry==null||$this->GetEntryValue('Value','')==='')
            return array();


        $value=$this->GetEntryValue('Value','');
        if(count($value)==0)
            return array();
        return array((object)\array_merge((array)$this->Entry,array(
            'HideInCart'=>false,
            'Id'=>$this->Options->Id,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        )));
    }

    public function GetHtml($document)
    {
        $table=new HtmlTagWrapper($document,$document->createElement('table'));
        $tbody=$table->CreateAndAppendChild('tbody');


        $columns=$this->GetOptionValue('Columns',array());

        if(count($columns)>0)
        {
            $row=$tbody->CreateAndAppendChild('tr');
            foreach ($columns as $currentColumn)
            {
                $td=$row->CreateAndAppendChild('th');
                $td->AddStyle('text-align','left');
                $td->SetText($currentColumn->Name);
            }
        }


        $rowValues=$this->GetEntryValue('Value',array());
        foreach($rowValues as $currentRow)
        {
            $tr=$tbody->CreateAndAppendChild('tr');
            foreach($currentRow as $currentColumn)
            {
                $td=$tr->CreateAndAppendChild('td');
                $td->AddStyle('margin-bottom','5px');
                $td->SetText($currentColumn);
            }
        }

        return $table;
    }


}
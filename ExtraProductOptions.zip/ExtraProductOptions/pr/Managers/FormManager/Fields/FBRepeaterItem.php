<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;



use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerDataRetriever;
use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerManager;
use rednaowooextraproduct\core\Managers\FormManager\FBRow;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\pr\Managers\FormManager\Calculator\GroupCalculator;

class FBRepeaterItem extends FBFieldBase implements ContainerDataRetriever
{
    /**
     * @var FBRow
     */
    public $Rows;
    /** @var ContainerManager */
    public $ContainerManager;
    public function __construct($loader, $fbColumn, $options, $entry = null)
    {
        parent::__construct($loader, $fbColumn, $options, $entry);
        $this->ContainerManager=new ContainerManager($this);
        $this->Calculator=new GroupCalculator($this);

        foreach ($options->RowTemplates as $row)
        {
            $row=new FBRow($this->Loader,$this,$row,$entry);
            if(count($row->Columns)>0)
                $this->Rows[]=$row;
        }





        foreach($this->Rows as $row)
        {
            foreach($row->Columns as $column)
            {
                $field=$column->Field;
                if(!$field->Calculator->GetDependsOnOtherFields())
                    $field->Calculator->ExecuteAndUpdate();;
            }

            foreach($row->Columns as $column)
            {
                $field=$column->Field;
                if($field->Calculator->GetDependsOnOtherFields())
                    $field->Calculator->ExecuteAndUpdate();;
            }
        }


    }

    public function GetProductRegularPrice(){
        return $this->GetForm()->GetProductRegularPrice();
    }

    public function GetProductSalePrice(){
        return $this->GetForm()->GetProductSalePrice();
    }


    public function GetAllFields()
    {
        $fields=[];
        foreach ($this->Rows as $row)
            foreach($row->Columns as $column)
            {
                $fields[]=$column->Field;
            }
        return $fields;
    }

    /**
     * @inheritDoc
     */
    public function GetRows()
    {
        return $this->Rows;
    }

    public function GetHtml($document)
    {
        return $this->ContainerManager->GetHtml($document);
    }


    public function GetContainerManager()
    {
        return $this->ContainerManager;
    }
}
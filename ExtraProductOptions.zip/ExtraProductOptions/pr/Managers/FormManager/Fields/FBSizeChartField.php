<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Fields;


use rednaowooextraproduct\core\Managers\ConditionManager\ConditionManager;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBFieldBase;
use rednaowooextraproduct\core\Utils\ArrayUtils;
use rednaowooextraproduct\core\Utils\ObjectUtils;
use rednaowooextraproduct\Utilities\ObjectSanitizer;
use rednaowooextraproduct\Utilities\Sanitizer;

class FBSizeChartField extends FBFieldBase
{


    public function GetSelectedOptions(){
        if($this->Entry==null)
            return [];
        $options= ObjectSanitizer::Sanitize($this->Entry->SelectedValues,[
            (object)[
                "Id"=>0,
                "Price"=>0,
                "Quantity"=>0,
                "RegularPrice"=>0,
                "SalePrice"=>0,
                "Total"=>0,
                "Columns"=>[
                    (object)[
                        "Id"=>"",
                        "Text"=>"",
                        "Price"=>0,
                        "Quantity"=>0,
                        "RegularPrice"=>0,
                        "SalePrice"=>0,
                        "Total"=>0
                    ]
                ]
            ]
        ]);
        $optionsToReturn=[];
        foreach($options as $currentOptions)
        {
            foreach($this->Options->Rows as $savedRow)
            {
                if($savedRow->Id==$currentOptions->Id)
                {
                    $currentOptions->Columns=$savedRow->Columns;
                    $optionsToReturn[]=$currentOptions;
                }
            }
        }


        return $optionsToReturn;
    }

    public function GetLineItems(){

        $this->Entry->Headers=[];
        $table="<table>";

        if($this->Options->Selectable&&$this->Options->IncludeHeaderRow)
        {
            $this->Entry->Headers=$this->Options->Headers;
           $table.='<thead>';
           foreach ($this->Options->Headers as $currentHeader)
           {
               $table.='<th>'.$currentHeader->Text.'</th>';
           }
            $table.='</thead>';
        }
        $table.='<tbody>';
        foreach($this->Entry->SelectedValues as $selectedRow)
        {
            $table.='<tr>';
            foreach ($selectedRow->Columns as $selectedColumn)
            {
               $table.='<td>';
               $table.=$selectedColumn->Text;
                $table.='</td>';
            }
            $table.='</tr>';
        }
        $table.='</tbody>';
        $table.='</table>';
        $this->Entry->Value=$table;


        return array((object)\array_merge((array)$this->Entry,array(
            'Id'=>$this->Options->Id,
            'FieldName'=>$this->Options->FieldName,
            'Type'=>$this->Options->Type
        )));
    }

    public function GetValue(){
        return $this->GetSelectedOptions();
    }

    public function GetText()
    {
        $values=$this->GetValue();
        $labels=\array_map(function ($value){return $value->Label;},$this->GetValue());
        return \implode(', ',$labels);
    }

    public function  Contains($value)
    {
        return ArrayUtils::Find( $this->GetSelectedOptions(),function ($item)use($value){
                return $item->Label==$value;
            })!=null;

    }

    public function GetPriceWithoutFormula(){
        $price=0;
        $options=$this->GetSelectedOptions();
        foreach($options as $currentOptions)
        {
            $price+=Sanitizer::SanitizeNumber($currentOptions->RegularPrice);
        }

        return $price;

    }

    public function GetPrice(){
        $options=$this->GetSelectedOptions();
        $price=0;
        foreach($options as $currentOption)
        {
            $currentPrice=\floatval($currentOption->RegularPrice);
            if($currentPrice===false)
                $currentPrice=0;

            $price+=$currentPrice;


        }

        return $price;

    }



}
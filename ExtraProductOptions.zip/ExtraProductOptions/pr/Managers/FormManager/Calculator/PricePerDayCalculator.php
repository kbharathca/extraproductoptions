<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Calculator;


use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorBase;

class PricePerDayCalculator extends CalculatorBase
{

    public function ExecutedCalculation($value)
    {
        $value=$this->Field->GetEntryValue('Value',null);
        if($value!=null)
        {
            $startDate=$value->StartUnix;;
            $endDate=$value->EndUnix;

            $value=0;
            if($startDate!=null&&$endDate!=null)
            {
                $alpha=$endDate-$startDate;
                if($alpha==0)
                    $value=1;
                else
                    $value=$alpha/(24*60*60);
            }

            $regularPriceToUse='';
            $salePriceToUse='';

            if($this->Field->GetRegularPrice()!='')
                $regularPriceToUse=$this->Field->GetRegularPrice()*$value;
            if($this->Field->GetSalePrice()!='')
                $salePriceToUse=$this->Field->GetSalePrice()*$value;



            if($salePriceToUse!='')
            {
                return $this->CreateCalculationObject($regularPriceToUse,$salePriceToUse,$this->GetQuantityInput());
            }else
                return $this->CreateCalculationObject($regularPriceToUse,'',$this->GetQuantityInput());
        }else
            return $this->CreateCalculationObject('','',0);
    }
}
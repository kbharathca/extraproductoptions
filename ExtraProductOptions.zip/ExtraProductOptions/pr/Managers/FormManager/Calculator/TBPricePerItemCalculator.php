<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Calculator;


use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorBase;
use rednaowooextraproduct\core\Managers\FormManager\Fields\FBTextualImageField;
use rednaowooextraproduct\Utilities\Sanitizer;

class TBPricePerItemCalculator extends CalculatorBase
{

    public function ExecutedCalculation($value)
    {
        /** @var FBTextualImageField $field */
        $field=$this->Field;
        $value=$field->GetValue();

        $price=0;
        foreach($value as $currentValue)
        {
            $price+=Sanitizer::SanitizeNumber($currentValue->Price);

        }

        return $this->CreateCalculationObject($price,0,1);
    }
}
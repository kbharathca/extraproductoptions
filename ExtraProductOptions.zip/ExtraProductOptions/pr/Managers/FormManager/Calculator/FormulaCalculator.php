<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Calculator;


use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorBase;
use rednaowooextraproduct\pr\Managers\FormulaManager\FormulaManager;
use rednaowooextraproduct\pr\Parser\Elements\ParseMain;

class FormulaCalculator extends CalculatorBase
{

    public function GetDependsOnOtherFields(){
        return true;
    }


    public function ExecutedCalculation($value)
    {
        $formula=FormulaManager::GetFormula($this->Field,'Price');
        if($formula==null)
            return $this->CreateCalculationObject('','',0);

        $fields=$this->Field->GetForm()->ContainerManager->Getfields(false,true,true);
        $formula=FormulaManager::GetFormula($this->Field,'Price');

        //$parser=new ParseMain($fields,$formula->Compiled,$this->Field);

        return $this->CreateCalculationObject(0,'',$this->GetQuantityInput());


    }
}
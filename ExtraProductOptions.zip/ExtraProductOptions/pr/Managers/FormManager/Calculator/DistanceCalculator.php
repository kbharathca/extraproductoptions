<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Calculator;


use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorBase;

class DistanceCalculator extends CalculatorBase
{

    public function ExecutedCalculation($value)
    {
        if($value==null)
            $value=$this->Field->GetValue();


        $field=$this->Field;
        $distance=$value->Distance;
        $price=0;
        if($distance>0)
        {
            if($field->Options->DistanceType=='Kilometer')
            {
                $price=$distance/1000*$field->Options->PricePerDistance;
            }

            if($field->Options->DistanceType=='Meter')
            {
                $price=$distance*$field->Options->PricePerDistance;
            }

            if($field->Options->DistanceType=='Mile')
            {
                $price=$distance*0.0006213712 *$field->Options->PricePerDistance;
            }
        }
        return $this->CreateCalculationObject($price,0,1);
    }
}
<?php


namespace rednaowooextraproduct\pr\Managers\FormManager\Calculator;


use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorBase;
use rednaowooextraproduct\core\Managers\FormManager\Calculator\CalculatorFactory;
use rednaowooextraproduct\core\Managers\FormManager\Calculator\GlobalCalculator;
use rednaowooextraproduct\core\Managers\FormManager\ContainerManager\ContainerDataRetriever;
use rednaowooextraproduct\core\Utils\ArrayUtils;
use rednaowooextraproduct\pr\Managers\FormManager\Fields\FBGroupPanel;

class GroupCalculator extends CalculatorBase
{
    public $Total;
    /** @var FBGroupPanel */
    public $Field;
    public $OptionsUnitPrice;

    public function ExecutedCalculation($value)
    {
        if($this->Field->Entry==null)
            return $this->CreateCalculationObject('','',0);
        $this->OptionsUnitPrice=0;
        $this->Quantity=0;

        /** @var ContainerDataRetriever */
        $containerField = $this->Field;

        foreach ($containerField->GetContainerManager()->GetFields(false, false, false) as $field)
        {
            if (!$field->Calculator->GetDependsOnOtherFields())
                $field->Calculator->ExecuteAndUpdate();
        }


        foreach ($containerField->GetContainerManager()->GetFields(false, false, false) as $field)
        {
            $this->OptionsUnitPrice += $field->Calculator->GetPrice();
        }

        $this->Quantity=0;
        foreach ($containerField->GetContainerManager()->GetFields(false, false, false) as $field)
        {
            if($field->Calculator instanceof GlobalCalculator)
                $this->Quantity+=$field->Calculator->GetQuantity();

        }


        if (!ArrayUtils::Some($containerField->GetContainerManager()->GetFields(false, false, false),
            function ($item) {
                return isset($item->Options->Pricetype)&& ($item->Options->PriceType == "global_quantity" || $item->Options->PriceType == "quantity_per_day");
            }))
        {
            $this->Quantity = 1;
        }


        $this->OptionsTotal=$this->OptionsUnitPrice*$this->Quantity;
        $this->GrandTotal=($this->OptionsUnitPrice+$this->GetPrice())*$this->Quantity;

        return $this->CreateCalculationObject($this->GrandTotal,'',1);
    }



}
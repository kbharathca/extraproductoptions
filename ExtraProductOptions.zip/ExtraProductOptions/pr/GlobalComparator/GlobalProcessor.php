<?php

namespace rednaowooextraproduct\pr\GlobalComparator;

use rednaowooextraproduct\core\Loader;
use rednaowooextraproduct\pr\Repositories\GlobalProductRepository;
use rednaowooextraproduct\repository\ProductRepository;

class GlobalProcessor
{
    /** @var Loader */
    private $loader;
    /** @var GlobalProductRepository */
    public $GlobalProductRepository;
    public function __construct($loader,$globalRepository=null)
    {
        $this->loader=$loader;
        if($globalRepository==null)
            $this->GlobalProductRepository=new GlobalProductRepository($loader);
        else
            $this->GlobalProductRepository=$globalRepository;

        add_filter('woo_extra_products_options_added',array($this,'ProcessProductExtraOptions'),10,2);
    }

    public function ProcessProductExtraOptions($options,$productId){
        $repository=new GlobalProductRepository($this->loader);
        $globalOptionConditions=$repository->GetConditions();
        if(count($globalOptionConditions)==0)
            return $options;




        $productHasOptions=false;
        if($options!=false)
        {
            $productHasOptions=true;
            $options=json_decode($options);
        }else{
            $options=(object)[
                "Rows"=>[],
                "Extensions"=>[],
                "DynamicFieldTypes"=>[],
                "Version"=>1,
                "Styles"=>"",
                "MapsApiKey"=>"",
                "Icons"=>[],
                "MultipleSteps"=>null,
                "OptionsAmountLabel"=>"Options Amount",
                "FinalTotalLabel"=>"Final Total",
                "OptionsAmountVisibility"=>"show",
                "TotalAmountVisibility"=>"show",
                "ExtensionsUsed"=>[],
                "AdditionalDependencies"=>[],
                'Fonts'=>[]

            ];
        }

        $product=wc_get_product($productId);
        if(!$product)
            return false;
        $comparator=new GlobalComparator($product);
        foreach($globalOptionConditions as $currentCondition)
        {
            if($comparator->ShouldInclude($currentCondition))
            {

                $this->AddOptions($currentCondition->Id,$options,$this->GetOptionsPosition($productHasOptions,$currentCondition->ConflictStyle),$productHasOptions);
            }

        }

        if(count($options->Rows)>0)
            return json_encode($options);
        else
            return false;
    }

    private function GetOptionsPosition($productHasOptions, $ConflictStyle)
    {
        if(!$productHasOptions)
            return 'bottom';


        return $ConflictStyle;
    }

    public function AddOptions($optionsId, $productOptions, $position,$productHasOptions)
    {
        if($position=='none')
            return;

        $options=null;
        $globalOptions=$this->GlobalProductRepository->GetGlobalOptionsById($optionsId);
        if($globalOptions!=null)
            $options=$globalOptions['Options'];


        $globalOptions=apply_filters('woo-extra-product-global-options-loaded',$globalOptions);
        $isMultiple=isset($options->MultipleSteps)&&$options->MultipleSteps!=null;
        if($isMultiple&&$productHasOptions)
        {
             return;
        }

        if(!$productHasOptions)
        {
            $this->MaybeAddProperty($productOptions,$options,'OptionsAmountLabel');
            $this->MaybeAddProperty($productOptions,$options,'FinalTotalLabel');
            $this->MaybeAddProperty($productOptions,$options,'OptionsAmountVisibility');
            $this->MaybeAddProperty($productOptions,$options,'TotalAmountVisibility');
            $this->MaybeAddProperty($productOptions,$options,'MultipleSteps');
            $this->MaybeAddProperty($productOptions,$options,'Fonts');
        }

        $options->DynamicFieldTypes[]='FBGlobalContainer';
        foreach($options->DynamicFieldTypes as $currentDynamicField)
        {
            if(!in_array($currentDynamicField,$productOptions->DynamicFieldTypes))
                $productOptions->DynamicFieldTypes[]=$currentDynamicField;

        }

        foreach($options->AdditionalDependencies as $additionalDependency)
        {
            if(!in_array($additionalDependency,$productOptions->AdditionalDependencies))
                $productOptions->AdditionalDependencies[]=$additionalDependency;
        }

        $globalId=1000000000+$optionsId;

        if(isset($options->Styles)&&trim($options->Styles)!='')
        {
            $productOptions->Styles .= ' ' . $this->ParseStyles($globalId,$options->Styles);
        }


        if(isset($options->Fonts))
        {
            if(!isset($productOptions->Fonts))
                $productOptions->Fonts=[];

            foreach($options->Fonts as $currentFont)
            {
                if(!in_array($currentFont,$productOptions->Fonts))
                    $productOptions->Fonts[]=$currentFont;
            }
        }




        if(!$isMultiple)
        {
            $globalContainer = new \stdClass();
            $globalContainer->Type = 'globalcontainer';
            $globalContainer->Rows = $options->Rows;
            $globalContainer->IsFieldContainer = true;
            $globalContainer->Id = $globalId;
            $globalContainer->GlobalId = $optionsId;
            $globalContainer->FieldName = '';

            $column = new \stdClass();
            $column->Field = $globalContainer;
            $column->WidthPercentage = 100;

            $row = new \stdClass();
            $row->StepId = 0;
            $row->Columns = [$column];

            if ($position == 'top')
                array_unshift($productOptions->Rows, $row);
            else
                array_push($productOptions->Rows, $row);
        }else{
            $productOptions->Rows=$options->Rows;
        }


    }

    private function MaybeAddProperty($newOptions, $originalOptions,$property)
    {
        if(isset($originalOptions->$property))
            $newOptions->$property=$originalOptions->$property;

    }

    private function ParseStyles($globalId, $styles)
    {
        $matches=null;
        preg_match_all('/([^{]*)({[^}]*})/',$styles,$matches,PREG_SET_ORDER);
        $newStyles='';
        foreach($matches as $currentMatch)
        {
            $selector=$currentMatch[1];
            $splitSelector=explode(',',$selector);

            $newSelector=[];
            foreach($splitSelector as $currentSelector)
                $newSelector[]='.rnField_'.$globalId.' '.$currentSelector;

            $newStyles.=implode(', ',$newSelector).$currentMatch[2]."\n";


        }

        return $newStyles;
    }

}
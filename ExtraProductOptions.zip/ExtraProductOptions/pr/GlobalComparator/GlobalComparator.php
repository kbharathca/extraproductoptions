<?php

namespace rednaowooextraproduct\pr\GlobalComparator;

use rednaowooextraproduct\core\Utils\ArrayUtils;
use rednaowooextraproduct\Utilities\Sanitizer;

class GlobalComparator
{
    /** @var \WC_Product */
    public $Product;
    public $Categories=null;
    public $Tags=null;
    public $Parent=null;
    public $Attributes=[];
    public function __construct($product)
    {
        $this->Product=$product;
    }

    /**
     * @param $product \WC_Product
     * @param $condition
     */
    public function ShouldInclude($condition)
    {
        $shouldInclude=false;
        if($condition->Include==null||!isset($condition->Include->ConditionGroups))
            return false;

       return $this->ProcessCondition($condition->Include->ConditionGroups);

    }

    public function ProcessCondition($conditionGroups)
    {
        foreach($conditionGroups as $conditionGroup)
        {
            $conditionIsValid=true;
            foreach($conditionGroup->ConditionLines as $conditionLine)
            {
                if(!$this->ProcessConditionLine($conditionLine)) {
                    $conditionIsValid=false;
                    break;
                }
            }

            if($conditionIsValid)
                return true;
        }

        return false;
    }

    public function ProcessConditionLine($conditionLine)
    {
        switch ($conditionLine->FieldId)
        {
            case 'product_category':
                return $this->ProcessMultiValueComparison($conditionLine,$this->GetCategory(),$conditionLine->Value);
            case 'product_tag':
                return $this->ProcessMultiValueComparison($conditionLine,$this->GetTags(),$conditionLine->Value);
            case 'product_attribute':
                switch ($conditionLine->Comparison)
                {
                    case "have_attribute":
                    case "does_not_have_attribute":
                        $attributeValue=$this->GetAttributeValue($conditionLine->Value);

                        if($conditionLine->Comparison=='have_attribute')
                            return count($attributeValue)>0;
                        else
                            return count($attributeValue)==0;
                        break;
                    case "Equal":
                    case "NotEqual":
                    case "Contains":
                    case "NotContains":
                        $attributeName=Sanitizer::GetStringValueFromPath($conditionLine,['Value','Name']);
                        $attributeValue=Sanitizer::GetStringValueFromPath($conditionLine,['Value','Value']);
                        if($attributeName=='')
                            return true;

                        $attributeValueList=$this->GetAttributeValue($attributeName);
                        switch ($conditionLine->Comparison)
                        {
                            case 'Equal':
                                return ArrayUtils::Some($attributeValueList,function ($item) use ($attributeValue){
                                    return $item==$attributeValue;
                                });
                            case 'NotEqual':
                                return !ArrayUtils::Some($attributeValueList,function ($item) use ($attributeValue){
                                    return $item==$attributeValue;
                                });
                            case 'Contains':
                                return ArrayUtils::Some($attributeValueList,function ($item) use ($attributeValue){
                                    return strpos($item,$attributeValue)!==false;
                                });

                            case 'NotContains':
                                return !ArrayUtils::Some($attributeValueList,function ($item) use ($attributeValue){
                                    return strpos($item,$attributeValue)!==false;
                                });
                            default:
                                return true;
                        }

                }

        }

        return true;
    }

    public function ProcessMultiValueComparison($condition,$haystack,$needle)
    {
        if(!is_array($haystack))
            $haystack=[$haystack];

        if(!is_array($needle))
            $needle=[$needle];


        $found=count(array_intersect($haystack,$needle))>0;
        if($condition->Comparison=='Contains')
            return $found;
        else
            return !$found;
    }

    private function GetParent(){
        if($this->Parent==null) {
            $parentId = $this->Product->get_parent_id();
            if ($parentId != null) {
                $parent = wc_get_product($parentId);
                if ($parent != false)
                    $this->Parent = $parent;
            }
        }

        return $this->Parent;
    }

    private function GetCategory()
    {
        if($this->Categories==null) {
            $this->Categories = $this->Product->get_category_ids();
            if ($this->Product->get_parent_id() != null) {
                $parent = $this->GetParent();
                if ($parent != null)
                    $this->Categories = array_merge($this->Categories, $parent->get_category_ids());
            }
        }

        return $this->Categories;
    }

    private function GetTags()
    {
        if($this->Tags==null) {
            $this->Tags = $this->Product->get_tag_ids();
            if ($this->Product->get_parent_id() != null) {
                $parent = $this->GetParent();
                if ($parent != null)
                    $this->Tags = array_merge($this->Tags, $parent->get_tag_ids());
            }
        }

        return $this->Tags;
    }

    private function GetAttributeValue($attributeName)
    {
        $attributeName=sanitize_title($attributeName);

        $attributes=$this->Product->get_attributes();
        if(!isset($attributes[$attributeName]))
            return [];


        /** @var \WC_Product_Attribute $attribute */
        $attribute=$attributes[$attributeName];
        return $attribute->get_options();

    }

}
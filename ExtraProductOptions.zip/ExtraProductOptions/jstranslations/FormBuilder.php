<?php return array(
"Required"=>__("Required","rednaowooextraproduct"),
"Next"=>__("Next","rednaowooextraproduct"),
"Previous"=>__("Previous","rednaowooextraproduct"),
"Add to cart"=>__("Add to cart","rednaowooextraproduct"),
"Options amount"=>__("Options amount","rednaowooextraproduct"),
"Final Total"=>__("Final Total","rednaowooextraproduct")
);
<?php return array(
"You selected"=>__("You selected","rednaowooextraproduct"),
"on"=>__("on","rednaowooextraproduct")
);
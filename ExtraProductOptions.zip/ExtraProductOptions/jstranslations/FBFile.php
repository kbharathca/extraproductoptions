<?php return array(
"Invalid file type"=>__("Invalid file type","rednaowooextraproduct")
);
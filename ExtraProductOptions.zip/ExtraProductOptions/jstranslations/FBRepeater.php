<?php return array(
"You need to add at least "=>__("You need to add at least ","rednaowooextraproduct"),
"items"=>__("items","rednaowooextraproduct")
);
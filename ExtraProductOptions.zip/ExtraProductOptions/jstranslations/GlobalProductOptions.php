<?php return array(
"Equal to"=>__("Equal to","rednaowooextraproduct"),
"Not Equal to"=>__("Not Equal to","rednaowooextraproduct"),
"Is Empty"=>__("Is Empty","rednaowooextraproduct"),
"Is Not Empty"=>__("Is Not Empty","rednaowooextraproduct"),
"Contains"=>__("Contains","rednaowooextraproduct"),
"Not Contains"=>__("Not Contains","rednaowooextraproduct"),
"Greater Than"=>__("Greater Than","rednaowooextraproduct"),
"Greater or Equal Than"=>__("Greater or Equal Than","rednaowooextraproduct"),
"Less Than"=>__("Less Than","rednaowooextraproduct"),
"Less or Equal Than"=>__("Less or Equal Than","rednaowooextraproduct"),
"Is Checked"=>__("Is Checked","rednaowooextraproduct"),
"Is Not Checked"=>__("Is Not Checked","rednaowooextraproduct")
);
<?php return array(
"Required"=>__("Required","rednaowooextraproduct"),
"Cancel"=>__("Cancel","rednaowooextraproduct"),
"Apply"=>__("Apply","rednaowooextraproduct")
);
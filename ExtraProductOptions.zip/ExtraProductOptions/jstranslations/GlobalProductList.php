<?php return array(
"Global Product Options"=>__("Global Product Options","rednaowooextraproduct"),
"Add new global option"=>__("Add new global option","rednaowooextraproduct"),
"Name"=>__("Name","rednaowooextraproduct"),
"Edit"=>__("Edit","rednaowooextraproduct"),
"Delete"=>__("Delete","rednaowooextraproduct"),
"Clone"=>__("Clone","rednaowooextraproduct"),
"Last Update"=>__("Last Update","rednaowooextraproduct"),
"Status"=>__("Status","rednaowooextraproduct"),
"Disabling"=>__("Disabling","rednaowooextraproduct"),
"Option disabled successfully"=>__("Option disabled successfully","rednaowooextraproduct"),
"Enabling"=>__("Enabling","rednaowooextraproduct"),
"Option enabled successfully"=>__("Option enabled successfully","rednaowooextraproduct"),
"Please confirm"=>__("Please confirm","rednaowooextraproduct"),
"Please select an action first"=>__("Please select an action first","rednaowooextraproduct")
);
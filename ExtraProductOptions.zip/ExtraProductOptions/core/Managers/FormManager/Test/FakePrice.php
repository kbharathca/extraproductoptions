<?php


namespace rednaowooextraproduct\core\Managers\FormManager\Test;


class FakePrice
{
    public function get_price(){
        return 10;
    }
}
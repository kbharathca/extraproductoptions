<?php


namespace rednaowooextraproduct\core\Managers\FormManager\Fields;


class FBNoneField extends FBFieldBase
{

}
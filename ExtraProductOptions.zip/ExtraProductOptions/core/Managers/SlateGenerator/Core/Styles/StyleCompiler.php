<?php


namespace rednaowooextraproduct\core\Managers\SlateGenerator\Core\Styles;


class StyleCompiler
{

}
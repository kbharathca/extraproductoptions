<?php


namespace rednaowooextraproduct\core\Managers\SlateGenerator\Block;


use rednaowooextraproduct\core\Managers\SlateGenerator\Core\NodeElementBase;

class Condition extends NodeElementBase
{

    /**
     * @inheritDoc
     */
    public function GetNodeName()
    {
        return 'div';
    }

    public function Process()
    {
        // TODO: Implement Process() method.
    }
}